@echo off
title EX IPTV Player v9.8 — Build
color 0A
cd /d "%~dp0"
echo.
echo  ============================================================
echo     EX IPTV Player v9.8
echo     Anbieter-Verwaltung + mpv eingebettet
echo  ============================================================
echo.

echo  [0/4]  Beende laufende EX-IPTV Prozesse...
taskkill /F /IM "EX-IPTV.exe" >nul 2>&1
taskkill /F /IM "EX-IPTV" >nul 2>&1
timeout /t 2 /nobreak >nul
echo  [OK]  Prozesse beendet (oder keine liefen)
echo.

echo  [1/4]  Python pruefen...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [FEHLER] Python nicht gefunden!
    echo  https://www.python.org/ -- "Add Python to PATH" ankreuzen
    pause & exit /b 1
)
python --version
echo.

echo  [2/4]  Pakete installieren...
python -m pip install --upgrade pip --quiet --no-warn-script-location
python -m pip install "Pillow>=10.0" "PyInstaller>=6.0" --quiet --no-warn-script-location
if %errorlevel% neq 0 (
    echo  [FEHLER] Paket-Installation fehlgeschlagen!
    pause & exit /b 1
)
echo  [OK]  Pillow + PyInstaller
echo.

echo  [3/4]  Assets generieren...
if not exist assets mkdir assets
python generate_sound.py
python generate_icon.py
echo  [OK]  Icons + Sound
echo.

echo  [4/4]  EXE bauen...
echo.
set ADDDATA=
if exist "assets\icon.ico"      set ADDDATA=%ADDDATA% --add-data "assets\icon.ico;assets"
if exist "assets\icon_hdr.png"  set ADDDATA=%ADDDATA% --add-data "assets\icon_hdr.png;assets"
if exist "assets\icon_256.png"  set ADDDATA=%ADDDATA% --add-data "assets\icon_256.png;assets"
if exist "assets\intro.wav"     set ADDDATA=%ADDDATA% --add-data "assets\intro.wav;assets"

python -m PyInstaller ^
    --noconfirm --clean --onefile --windowed ^
    --name "EX-IPTV" ^
    --icon "assets\icon.ico" ^
    %ADDDATA% ^
    --hidden-import sqlite3 ^
    --hidden-import PIL --hidden-import PIL.Image --hidden-import PIL.ImageTk ^
    --exclude-module vlc ^
    --exclude-module matplotlib ^
    --exclude-module numpy ^
    --exclude-module scipy ^
    main.py

if %errorlevel% neq 0 (
    echo.
    echo  [FEHLER] Build fehlgeschlagen!
    echo  Tipp: Antivirus deaktivieren und nochmal versuchen.
    pause & exit /b 1
)

echo.
echo  ============================================================
echo     BUILD ERFOLGREICH!  v9.8
echo.
echo     EXE:   %~dp0dist\EX-IPTV.exe
echo.
echo     Neues in v9.8:
echo       - Anbieter-Tab mit Karten-Verwaltung
echo       - Toggle-Switch pro Anbieter
echo       - Umbenennen, Aktualisieren, Loeschen
echo       - Xtream Codes + URL + Datei Import
echo       - Auto-Retry (bis 10 Versuche)
echo       - Echtzeit Import-Log
echo       - mpv eingebettet (kein externes Fenster)
echo.
echo     WICHTIG: Beim ersten Start wird mpv installiert
echo              (winget oder automatischer Download)
echo  ============================================================
echo.

:: Desktop-Verknuepfung erstellen
set SCRIPT=%~dp0_sc.vbs
(
    echo Set oWS = WScript.CreateObject("WScript.Shell")
    echo sLinkFile = oWS.SpecialFolders("Desktop") ^& "\EX IPTV.lnk"
    echo Set oLink = oWS.CreateShortcut(sLinkFile)
    echo oLink.TargetPath = "%~dp0dist\EX-IPTV.exe"
    echo oLink.WorkingDirectory = "%~dp0dist"
    echo oLink.Description = "EX IPTV Player v9.8"
    echo oLink.Save
) > "%SCRIPT%"
cscript //nologo "%SCRIPT%" >nul 2>&1
if exist "%SCRIPT%" del "%SCRIPT%" >nul 2>&1
echo  [OK]  Desktop-Verknuepfung erstellt
echo.

choice /c JN /n /m "  Jetzt starten? (J/N): "
if %errorlevel%==1 start "" "%~dp0dist\EX-IPTV.exe"
pause
