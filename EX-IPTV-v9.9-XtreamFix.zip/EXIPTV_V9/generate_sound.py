"""
EX IPTV — Sound Generator
Erstellt assets/intro.wav (kurzer Startup-Sound).
Kein externes Tool nötig — nur Python Standard-Bibliothek.
"""
import wave, struct, math, os


def make_wav(path, notes, sr=44100):
    frames = []
    for freq, dur, vol in notes:
        n = int(sr * dur)
        for i in range(n):
            t = i / sr
            # Sinus + leichtes Attack/Decay
            env = min(1.0, t / 0.02) * min(1.0, (dur - t) / 0.05)
            v = vol * env * math.sin(2 * math.pi * freq * t)
            frames.append(struct.pack('<h', int(v * 32767)))
    os.makedirs(os.path.dirname(path) if os.path.dirname(path) else ".", exist_ok=True)
    with wave.open(path, 'w') as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(sr)
        wf.writeframes(b"".join(frames))


def main():
    notes = [
        (523, 0.12, 0.55),   # C5
        (659, 0.12, 0.55),   # E5
        (784, 0.20, 0.65),   # G5
    ]
    make_wav("assets/intro.wav", notes)
    print("  ✅ intro.wav")


if __name__ == "__main__":
    main()
