"""
EX IPTV Player v9.0
- mpv wird beim ersten Start automatisch heruntergeladen
- Einfachste mögliche Wiedergabe: subprocess + mpv
- Kein HWND/Embedding → kein schwarzes Bild möglich
"""
import tkinter as tk
from tkinter import filedialog, messagebox
import threading, os, sys, re, json, pickle, sqlite3, time
import urllib.request, urllib.error, ssl, subprocess
import zipfile, shutil, tempfile
from datetime import datetime

try:    from PIL import Image, ImageTk; PIL_OK = True
except: PIL_OK = False

# ── Farben ──────────────────────────────────────────────────
C = {
    "bg":"#080810","side":"#0c0c1a","panel":"#0f0f20","card":"#141428",
    "card2":"#1a1a32","hdr":"#0a0a1e","red":"#e02020","red2":"#ff4444",
    "red3":"#8b0000","cyan":"#00d4ff","cyan2":"#00aacc","purple":"#7b2fff",
    "purple2":"#5a1fcc","green":"#00e676","yellow":"#ffd600",
    "orange":"#ff9500","teal":"#00bfa5","text":"#eeeeff","text2":"#aaaacc",
    "dim":"#505070","inp":"#16162e","bord":"#1e1e3c","bord2":"#2a2a50","black":"#000000",
}
F    = "Segoe UI"
HOME = os.path.join(os.path.expanduser("~"), "EX-IPTV")
DB   = os.path.join(HOME, "data.db")
CW_F = os.path.join(HOME, "cw.pkl")
UA   = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
CNW  = 0x08000000  # CREATE_NO_WINDOW (Windows)

# mpv Download-URL (offizieller Build, kein Installer nötig)
MPV_DOWNLOAD = "https://github.com/shinchiro/mpv-winbuild-cmake/releases/download/20240901/mpv-x86_64-20240901-git-9c06afe.zip"
MPV_FALLBACK = "https://sourceforge.net/projects/mpv-player-windows/files/64bit/mpv-x86_64-20240901.zip/download"

def ensure_home(): os.makedirs(HOME, exist_ok=True)
def res(p):
    base = sys._MEIPASS if hasattr(sys,"_MEIPASS") else os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, p)
def fmt_time(ms):
    if ms<=0: return "0:00"
    s=int(ms)//1000; m=s//60; h=m//60
    return f"{h}:{m%60:02d}:{s%60:02d}" if h else f"{m:02d}:{s%60:02d}"

# ═══════════════════════════════════════════════════════════
# DATABASE / CONFIG
# ═══════════════════════════════════════════════════════════
def dbconn():
    ensure_home()
    c = sqlite3.connect(DB, timeout=5); c.row_factory = sqlite3.Row; return c

def db_init():
    with dbconn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS playlists(
            slot INTEGER PRIMARY KEY, name TEXT, src TEXT,
            stype TEXT DEFAULT 'file', exp TEXT DEFAULT '', pid INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
        """)

def cfg_get(k, d=None):
    try:
        with dbconn() as c:
            r = c.execute("SELECT v FROM settings WHERE k=?", (k,)).fetchone()
            return json.loads(r[0]) if r else d
    except: return d

def cfg_set(k, v):
    try:
        with dbconn() as c:
            c.execute("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)", (k, json.dumps(v)))
    except: pass

def pl_all():
    try:
        with dbconn() as c: return [dict(r) for r in c.execute("SELECT * FROM playlists ORDER BY slot")]
    except: return []

def pl_get(slot):
    try:
        with dbconn() as c:
            r = c.execute("SELECT * FROM playlists WHERE slot=?", (slot,)).fetchone()
            return dict(r) if r else None
    except: return None

def pl_save(slot, name, src, stype, exp=""):
    pid = int(time.time()*1000) % 9999999
    with dbconn() as c:
        c.execute("""INSERT INTO playlists(slot,name,src,stype,exp,pid) VALUES(?,?,?,?,?,?)
                     ON CONFLICT(slot) DO UPDATE SET name=excluded.name,src=excluded.src,
                     stype=excluded.stype,exp=excluded.exp,pid=excluded.pid""",
                  (slot,name,src,stype,exp,pid))
    return pid

def pl_del(slot):
    pl = pl_get(slot)
    if pl and pl.get("pid"): ch_del(pl["pid"])
    with dbconn() as c: c.execute("DELETE FROM playlists WHERE slot=?", (slot,))

# ═══════════════════════════════════════════════════════════
# KANAL-CACHE
# ═══════════════════════════════════════════════════════════
def ch_path(pid): return os.path.join(HOME, f"ch_{pid}.pkl")

def ch_save(pid, channels, cb=None):
    rows = [{"name":c.get("name","")[:200],"url":c.get("url",""),
             "grp":c.get("group_title","")[:120],"cat":c.get("category","live"),
             "logo":c.get("tvg_logo","")[:300],"sn":c.get("series_name","")[:200],
             "se":c.get("season",""),"ep":c.get("episode","")}
            for c in channels if c.get("url")]
    if cb: cb(f"💾 Speichere {len(rows):,}...", 92)
    ensure_home()
    with open(ch_path(pid),"wb") as f: pickle.dump(rows, f, protocol=4)
    if cb: cb(f"✅ {len(rows):,} gespeichert!", 100)
    return len(rows)

def ch_del(pid):
    p = ch_path(pid)
    if os.path.exists(p):
        try: os.remove(p)
        except: pass

def ch_load(pid):
    p = ch_path(pid)
    if not os.path.exists(p): return []
    try:
        with open(p,"rb") as f: return pickle.load(f)
    except: return []

# ═══════════════════════════════════════════════════════════
# CONTINUE WATCHING
# ═══════════════════════════════════════════════════════════
def cw_load():
    if not os.path.exists(CW_F): return {}
    try:
        with open(CW_F,"rb") as f: return pickle.load(f)
    except: return {}

def cw_save_all(d):
    ensure_home()
    with open(CW_F,"wb") as f: pickle.dump(d, f, protocol=4)

def cw_update(ch, pos_ms, dur_ms):
    if pos_ms < 3000: return
    data = cw_load(); key = (ch.get("url") or "")[:200]
    if not key: return
    data[key] = {"name":ch.get("name",""),"grp":ch.get("grp",""),
                 "cat":ch.get("cat","video"),"url":ch.get("url",""),
                 "sn":ch.get("sn",""),"se":ch.get("se",""),"ep":ch.get("ep",""),
                 "pos_ms":int(pos_ms),"dur_ms":int(dur_ms),"ts":time.time()}
    if len(data)>60:
        for k in sorted(data,key=lambda k:data[k].get("ts",0))[:len(data)-60]: del data[k]
    cw_save_all(data)

def cw_get_all():
    return sorted(cw_load().values(), key=lambda x:x.get("ts",0), reverse=True)

def cw_remove(url):
    data=cw_load(); key=(url or "")[:200]
    if key in data: del data[key]; cw_save_all(data)

# ═══════════════════════════════════════════════════════════
# M3U PARSER + FORMAT-ERKENNUNG
# ═══════════════════════════════════════════════════════════

RE_SER_URL = re.compile(r'/series/|/serie/', re.I)
RE_MOV_URL = re.compile(r'/movie/|/film/|/vod/', re.I)
RE_LIV_URL = re.compile(r'/live/|/livetv/', re.I)
RE_SER_GRP = re.compile(r'\b(serie[ns]?|show|staffel|season|soap|sitcom|tv.show)\b', re.I)
RE_MOV_GRP = re.compile(r'\b(movie|film|vod|kino|cinema|spielfilm|4k.movie)\b', re.I)
RE_EPISODE  = re.compile(r'S\d{1,2}\s*E\d{1,3}|\bSeason\s*\d+\b', re.I)
RE_VOD_EXT  = re.compile(r'\.(mp4|mkv|avi|mov|wmv|flv|m4v)(\?|$)', re.I)
RE_JUNK     = re.compile(r'^[^a-zA-ZÀ-ÿА-яёÄÖÜäöüß0-9]+')

def categorize(name, group, url):
    u = url.lower(); g = (group or "").lower(); n = (name or "").lower()
    if RE_LIV_URL.search(u): return "live"
    if RE_SER_URL.search(u): return "series"
    if RE_MOV_URL.search(u): return "video"
    if RE_VOD_EXT.search(u): return "video"
    if RE_EPISODE.search(n): return "series"
    if RE_SER_GRP.search(g): return "series"
    if RE_MOV_GRP.search(g): return "video"
    return "live"

def detect_format(text):
    t = text.strip()[:3000].lower()
    if "#extm3u" in t or "#extinf" in t: return "m3u"
    if "<playlist" in t and "<track" in t: return "xspf"
    if "[playlist]" in t and "file1=" in t: return "pls"
    lines = [l.strip() for l in text.splitlines() if l.strip() and not l.startswith("#")]
    if lines and all(l.startswith(("http","rtmp","rtsp","udp","rtp")) for l in lines[:10]):
        return "url_list"
    return "unknown"

def parse_m3u(text, cb=None):
    channels = []; cur = {}; lines = text.splitlines(); total = max(len(lines),1)
    for i, line in enumerate(lines):
        line = line.strip()
        if not line: continue
        if line.startswith("#EXTINF"):
            cur = {}
            ci = line.rfind(",")
            cur["name"] = line[ci+1:].strip() if ci != -1 else "Channel"
            seg = line[:ci] if ci != -1 else line
            for m in re.finditer(r'([\w-]+)=["\'](.*?)["\']', seg):
                cur[m.group(1).lower().replace("-","_")] = m.group(2)
            cur["group_title"] = cur.get("group_title","").strip() or "Allgemein"
        elif line.startswith("#EXTGRP:"):
            cur["group_title"] = line[8:].strip()
        elif not line.startswith("#") and cur.get("name"):
            cur["url"] = line
            cat = categorize(cur["name"], cur.get("group_title",""), line)
            cur["category"] = cat
            if cat == "series":
                m2 = re.search(r'S(\d{1,2})\s*E(\d{1,3})', cur["name"], re.I)
                cur["season"]       = m2.group(1).zfill(2) if m2 else "01"
                cur["episode"]      = m2.group(2).zfill(3) if m2 else "001"
                raw = cur["name"][:m2.start()].strip() if m2 else cur["name"]
                sn = RE_JUNK.sub("", raw).strip()
                cur["series_name"]  = sn if sn else raw.strip()
            channels.append(cur.copy()); cur = {}
            if cb and len(channels) % 5000 == 0:
                cb(f"Geparst: {len(channels):,}...", 10+min(int(i/total*75),75))
    return channels

def parse_url_list(text, cb=None):
    channels = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"): continue
        channels.append({"name":f"Kanal {len(channels)+1}","url":line,
                          "group_title":"Import","category":"live","tvg_logo":""})
    return channels

def parse_xspf(text, cb=None):
    channels = []
    try:
        import xml.etree.ElementTree as ET
        ns = {"x":"http://xspf.org/ns/0/"}
        root = ET.fromstring(text)
        for t in root.findall(".//x:track", ns):
            loc  = t.findtext("x:location", default="", namespaces=ns)
            name = t.findtext("x:title",    default="Kanal",  namespaces=ns)
            if loc: channels.append({"name":name,"url":loc,"group_title":"Import",
                                      "category":"live","tvg_logo":""})
    except: pass
    return channels

def parse_pls(text, cb=None):
    channels=[]; urls={}; titles={}
    for line in text.splitlines():
        m=re.match(r'File(\d+)=(.+)', line, re.I)
        if m: urls[m.group(1)]=m.group(2).strip()
        m=re.match(r'Title(\d+)=(.+)', line, re.I)
        if m: titles[m.group(1)]=m.group(2).strip()
    for k,u in sorted(urls.items()):
        channels.append({"name":titles.get(k,f"Kanal {k}"),"url":u,
                          "group_title":"Import","category":"live","tvg_logo":""})
    return channels

def parse_any(text, fmt=None, cb=None):
    if fmt is None: fmt = detect_format(text)
    if cb: cb(f"Format erkannt: {fmt.upper()}", 82)
    if fmt == "m3u":      return parse_m3u(text, cb)
    if fmt == "xspf":     return parse_xspf(text, cb)
    if fmt == "pls":      return parse_pls(text, cb)
    if fmt == "url_list": return parse_url_list(text, cb)
    ch = parse_m3u(text, cb)
    return ch if ch else parse_url_list(text, cb)

def find_expiry(text):
    m = re.search(r'(?:expires?|expiry|valid.until)[=:\s]+(\d{4}-\d{2}-\d{2})', text[:3000], re.I)
    return m.group(1) if m else ""

def read_file(path, cb=None):
    if cb: cb(f"Lese Datei ({os.path.getsize(path)//1024:,} KB)...", 5)
    with open(path,"rb") as f: raw=f.read()
    for enc in ("utf-8","utf-8-sig","latin-1","cp1252"):
        try: return raw.decode(enc)
        except: pass
    return raw.decode("utf-8", errors="ignore")


# ═══════════════════════════════════════════════════════════
# NETZWERK-HELFER
# ═══════════════════════════════════════════════════════════

def _make_ctx():
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode    = ssl.CERT_NONE
    return ctx

def _http_get(url, timeout=45, extra_headers=None):
    """Einfacher HTTP-GET mit SSL-Bypass und Retry auf HTTP falls HTTPS scheitert."""
    hdrs = {"User-Agent": UA, "Accept": "*/*", "Connection": "keep-alive"}
    if extra_headers: hdrs.update(extra_headers)
    ctx = _make_ctx()
    urls_to_try = [url]
    if url.startswith("https://"):
        urls_to_try.append(url.replace("https://","http://",1))
    last_err = ""
    for u in urls_to_try:
        try:
            req = urllib.request.Request(u, headers=hdrs)
            with urllib.request.urlopen(req, context=ctx, timeout=timeout) as r:
                data = r.read()
            return data
        except Exception as e:
            last_err = str(e)
    raise Exception(last_err)

def _ps_get(url, timeout=60):
    """PowerShell WebClient Download (Windows HTTP-Stack, Proxy-Support)."""
    if sys.platform != "win32": return None
    import tempfile
    tmp = tempfile.mktemp(suffix=".dat")
    ps = (
        "$ProgressPreference='SilentlyContinue';"
        "try{"
        "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;"
        "$wc=New-Object System.Net.WebClient;"
        f"$wc.Headers['User-Agent']='{UA}';"
        f"$wc.DownloadFile('{url}','{tmp}');"
        "Write-Output 'OK'"
        "}catch{Write-Output \"ERR:$_\"}"
    )
    try:
        r = subprocess.run(
            ["powershell","-NoProfile","-NonInteractive","-ExecutionPolicy","Bypass","-Command",ps],
            capture_output=True, text=True, timeout=timeout,
            creationflags=CNW if sys.platform=="win32" else 0)
        if "OK" in r.stdout and os.path.isfile(tmp) and os.path.getsize(tmp) > 0:
            with open(tmp,"rb") as f: data=f.read()
            try: os.remove(tmp)
            except: pass
            return data
    except: pass
    try: os.remove(tmp)
    except: pass
    return None

def _decode(raw):
    for enc in ("utf-8","utf-8-sig","latin-1","cp1252"):
        try: return raw.decode(enc)
        except: pass
    return raw.decode("utf-8",errors="ignore")

def fetch_url(url, cb=None, max_attempts=5):
    """
    Lädt URL herunter — urllib → PowerShell → HTTP-Fallback.
    Bei Fehler: bis zu max_attempts Versuche mit wachsendem Delay.
    """
    url = url.strip()
    if "get.php" in url:
        if "type=" not in url: url += ("&" if "?" in url else "?") + "type=m3u_plus"
        if "output=" not in url: url += "&output=ts"

    last_err = ""
    for att in range(1, max_attempts+1):
        if att > 1:
            d = min(att*3, 15)
            if cb: cb(f"Versuch {att}/{max_attempts} — warte {d}s...", 3+att*2)
            time.sleep(d)
        else:
            if cb: cb(f"Verbinde... (Versuch 1/{max_attempts})", 5)

        # A: urllib
        try:
            raw = _http_get(url, timeout=45)
            if raw and len(raw) > 80:
                if cb: cb(f"Download OK ({len(raw)//1024} KB)", 78)
                return _decode(raw)
            last_err = f"Zu kurz: {len(raw)} Bytes"
        except Exception as e:
            last_err = str(e)
            if cb: cb(f"urllib: {last_err[:60]}", 3+att*2)

        # B: PowerShell (jeder 2. Versuch)
        if att % 2 == 0:
            if cb: cb("PowerShell-Versuch...", 5+att*2)
            raw = _ps_get(url, timeout=60)
            if raw and len(raw) > 80:
                if cb: cb(f"PowerShell OK ({len(raw)//1024} KB)", 78)
                return _decode(raw)

    raise Exception(f"Alle {max_attempts} Versuche fehlgeschlagen: {last_err}")


# ═══════════════════════════════════════════════════════════
# XTREAM CODES JSON-API ENGINE
# ═══════════════════════════════════════════════════════════

def _xtream_api(host, user, pwd, action, cb=None, extra=""):
    """Ruft Xtream Codes JSON-API auf."""
    host = host.strip().rstrip("/")
    if not re.match(r'https?://', host, re.I):
        host = "http://" + host
    url = f"{host}/player_api.php?username={user}&password={pwd}&action={action}{extra}"
    if cb: cb(f"API: {action}...", None)
    try:
        raw = _http_get(url, timeout=30)
        if not raw: return None
        return json.loads(_decode(raw))
    except Exception as e:
        # PowerShell Fallback
        raw = _ps_get(url, timeout=40)
        if raw:
            try: return json.loads(_decode(raw))
            except: pass
        if cb: cb(f"API {action} Fehler: {str(e)[:60]}", None)
        return None

def _xtream_validate(host, user, pwd, cb=None):
    """Prüft Xtream-Zugangsdaten via player_api.php (kein action)."""
    host = host.strip().rstrip("/")
    if not re.match(r'https?://', host, re.I): host = "http://" + host
    url = f"{host}/player_api.php?username={user}&password={pwd}"
    if cb: cb("Zugangsdaten prüfen...", 5)
    try:
        raw = _http_get(url, timeout=20)
        if not raw:
            raw = _ps_get(url, timeout=30)
        if not raw: return None, "Keine Antwort vom Server"
        data = json.loads(_decode(raw))
        if "user_info" in data:
            info = data["user_info"]
            status = info.get("status","")
            if status == "Active": return data, None
            if status:             return data, f"Konto-Status: {status}"
            return data, None
        if "auth" in data and not data.get("auth"):
            return None, "Authentifizierung fehlgeschlagen (401) — Benutzername/Passwort prüfen"
        return data, None
    except json.JSONDecodeError:
        return None, "Server-Antwort kein JSON — möglicherweise falscher Host"
    except Exception as e:
        return None, str(e)

def import_xtream(host, user, pwd, output_fmt="ts", cb=None):
    """
    Vollständiger Xtream-Import via JSON-API.
    Lädt Live, VOD und Serien separat und baut Stream-URLs.
    Viel zuverlässiger als get.php M3U-Download.
    """
    host = host.strip().rstrip("/")
    if not re.match(r'https?://', host, re.I): host = "http://" + host

    channels = []

    def _prog(msg, pct=None):
        if cb: cb(msg, pct)

    # ── 1. Validierung ─────────────────────────────────────
    _prog("Verbindung prüfen...", 5)
    info_data, err = _xtream_validate(host, user, pwd, cb)
    if err:
        raise Exception(err)
    exp = ""
    if info_data and "user_info" in info_data:
        ui = info_data["user_info"]
        if ui.get("exp_date"):
            try:
                import datetime as _dt
                exp = _dt.datetime.fromtimestamp(int(ui["exp_date"])).strftime("%Y-%m-%d")
            except: pass
    _prog(f"Verbindung OK{' · Gültig bis '+exp if exp else ''}", 10)

    # ── 2. Live-Kategorien ─────────────────────────────────
    _prog("Live-Kategorien laden...", 14)
    live_cats = _xtream_api(host, user, pwd, "get_live_categories") or []
    cat_map = {str(c.get("category_id","")): c.get("category_name","") for c in live_cats}

    # ── 3. Live-Sender ─────────────────────────────────────
    _prog("Live-Sender laden...", 20)
    live_streams = _xtream_api(host, user, pwd, "get_live_streams") or []
    _prog(f"{len(live_streams):,} Live-Sender gefunden", 30)
    for s in live_streams:
        sid  = s.get("stream_id","")
        name = s.get("name","") or s.get("stream_display_name","")
        grp  = cat_map.get(str(s.get("category_id","")), s.get("category_name","Live"))
        logo = s.get("stream_icon","")
        url  = f"{host}/live/{user}/{pwd}/{sid}.{output_fmt}"
        channels.append({
            "name":        name,
            "url":         url,
            "group_title": grp or "Live",
            "category":    "live",
            "tvg_logo":    logo,
        })

    # ── 4. VOD-Kategorien ──────────────────────────────────
    _prog("Film-Kategorien laden...", 35)
    vod_cats = _xtream_api(host, user, pwd, "get_vod_categories") or []
    vod_cat_map = {str(c.get("category_id","")): c.get("category_name","") for c in vod_cats}

    # ── 5. Filme ───────────────────────────────────────────
    _prog("Filme laden...", 42)
    vod_streams = _xtream_api(host, user, pwd, "get_vod_streams") or []
    _prog(f"{len(vod_streams):,} Filme gefunden", 55)
    for s in vod_streams:
        sid    = s.get("stream_id","")
        name   = s.get("name","") or s.get("title","")
        grp    = vod_cat_map.get(str(s.get("category_id","")), s.get("category_name","Filme"))
        logo   = s.get("stream_icon","") or s.get("cover","")
        ext    = s.get("container_extension","mp4") or "mp4"
        url    = f"{host}/movie/{user}/{pwd}/{sid}.{ext}"
        channels.append({
            "name":        name,
            "url":         url,
            "group_title": grp or "Filme",
            "category":    "video",
            "tvg_logo":    logo,
        })

    # ── 6. Serien-Kategorien ───────────────────────────────
    _prog("Serien-Kategorien laden...", 60)
    ser_cats = _xtream_api(host, user, pwd, "get_series_categories") or []
    ser_cat_map = {str(c.get("category_id","")): c.get("category_name","") for c in ser_cats}

    # ── 7. Serien (als Episoden-Streams) ───────────────────
    _prog("Serien laden...", 67)
    series_list = _xtream_api(host, user, pwd, "get_series") or []
    _prog(f"{len(series_list):,} Serien gefunden — Episoden werden geladen...", 72)

    # Jede Serie: Episoden einzeln laden
    total_ser = max(len(series_list), 1)
    for i, serie in enumerate(series_list):
        if i % 20 == 0:
            pct = 72 + int(i/total_ser * 15)
            _prog(f"Serien-Episoden: {i}/{total_ser}...", pct)

        series_id   = serie.get("series_id","")
        series_name = serie.get("name","")
        grp = ser_cat_map.get(str(serie.get("category_id","")),
                               serie.get("category_name","Serien"))
        logo = serie.get("cover","")

        # Episoden der Serie laden
        ep_data = _xtream_api(host, user, pwd, "get_series_info",
                               extra=f"&series_id={series_id}")
        if not ep_data or "episodes" not in ep_data:
            # Fallback: Serie ohne Episoden als Platzhalter
            channels.append({
                "name":        series_name,
                "url":         f"{host}/series/{user}/{pwd}/{series_id}.ts",
                "group_title": grp or "Serien",
                "category":    "series",
                "series_name": series_name,
                "season":      "01",
                "episode":     "001",
                "tvg_logo":    logo,
            })
            continue

        for season_num, episodes in ep_data["episodes"].items():
            for ep in (episodes or []):
                ep_id  = ep.get("id","")
                ep_num = str(ep.get("episode_num","1")).zfill(3)
                ext    = ep.get("container_extension","ts") or "ts"
                ep_name = ep.get("title","") or f"Episode {ep_num}"
                url     = f"{host}/series/{user}/{pwd}/{ep_id}.{ext}"
                channels.append({
                    "name":        f"{series_name} S{str(season_num).zfill(2)}E{ep_num} - {ep_name}",
                    "url":         url,
                    "group_title": grp or "Serien",
                    "category":    "series",
                    "series_name": series_name,
                    "season":      str(season_num).zfill(2),
                    "episode":     ep_num,
                    "tvg_logo":    logo,
                })

    _prog(f"Fertig: {len(channels):,} Einträge total", 90)
    return channels, exp


# ═══════════════════════════════════════════════════════════
# IMPORT DIALOG — Hochwertiges Playlist-Import-Tool
# ═══════════════════════════════════════════════════════════
class ImportDlg(tk.Toplevel):
    """
    Professionelles Playlist-Import-Tool.

    Modi:
      📂 Datei   — M3U/M3U8/TXT/PLS/XSPF lokal
      🌐 URL     — HTTP/HTTPS Direktlink, mit Auto-Retry
      📡 Xtream  — Xtream Codes JSON-API (zuverlässiger als get.php!)

    Xtream-Import nutzt player_api.php:
      get_live_streams + get_vod_streams + get_series
      → Live, Filme und Serien werden alle korrekt erkannt.
    """
    def __init__(self, root, slot, on_ok):
        super().__init__(root)
        self.slot  = slot
        self.on_ok = on_ok
        self._stop = threading.Event()
        self.title(f"Playlist importieren — Slot {slot}")
        self.configure(bg=C["panel"])
        self.resizable(True, True)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self._close)
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w, h = min(820, sw-80), min(680, sh-60)
        self.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")
        self.minsize(680, 540)
        self._build()
        self.bind("<Escape>", lambda e: self._close())

    # ── UI ────────────────────────────────────────────────
    def _build(self):
        # Header
        hf = tk.Frame(self, bg=C["red3"], height=52)
        hf.pack(fill="x"); hf.pack_propagate(False)
        tk.Label(hf, text=f"  📋  Playlist importieren — Slot {self.slot}",
                 bg=C["red3"], fg="white", font=(F,12,"bold")).pack(side="left", padx=14, pady=14)

        # Tabs
        tab_bar = tk.Frame(self, bg=C["card2"]); tab_bar.pack(fill="x")
        self._mode = tk.StringVar(value="xtream")
        self._tab_btns = {}
        for key, ico, lbl in [("file","📂","Datei"),
                               ("url", "🌐","URL"),
                               ("xtream","📡","Xtream Codes")]:
            b = tk.Button(tab_bar, text=f" {ico}  {lbl} ",
                          command=lambda k=key: self._sw(k),
                          bg=C["red3"] if key=="xtream" else C["card2"],
                          fg="white"   if key=="xtream" else C["dim"],
                          font=(F,9,"bold"), relief="flat", cursor="hand2",
                          padx=12, pady=8)
            b.pack(side="left"); self._tab_btns[key] = b

        # Body: Links = Eingaben, Rechts = Log
        outer = tk.Frame(self, bg=C["panel"]); outer.pack(fill="both", expand=True)
        left  = tk.Frame(outer, bg=C["panel"]); left.pack(side="left", fill="both", expand=True, padx=16, pady=12)
        right = tk.Frame(outer, bg=C["black"], width=300); right.pack(side="right", fill="both")
        right.pack_propagate(False)

        # Eingabe-Frame (wechselt je Tab)
        self._inp = tk.Frame(left, bg=C["panel"]); self._inp.pack(fill="x")

        # Name
        tk.Frame(left, bg=C["bord"], height=1).pack(fill="x", pady=8)
        tk.Label(left, text="Playlist-Name:", bg=C["panel"], fg=C["dim"], font=(F,9)).pack(anchor="w")
        self._name = tk.StringVar(value=f"Playlist {self.slot}")
        self._ent(left, self._name).pack(fill="x", ipady=5, pady=(2,8))

        # Retry
        self._retry_row = tk.Frame(left, bg=C["panel"]); self._retry_row.pack(fill="x")
        tk.Label(self._retry_row, text="Versuche:", bg=C["panel"], fg=C["dim"], font=(F,9)).pack(side="left")
        self._retries = tk.IntVar(value=5)
        tk.Spinbox(self._retry_row, from_=1, to=10, width=4, textvariable=self._retries,
                   bg=C["inp"], fg=C["text"], font=(F,9), relief="flat",
                   buttonbackground=C["card2"]).pack(side="left", padx=6)
        tk.Label(self._retry_row, text="(Auto-Delay zwischen Versuchen)",
                 bg=C["panel"], fg=C["dim"], font=(F,8)).pack(side="left")

        # Fortschritt
        tk.Frame(left, bg=C["bord"], height=1).pack(fill="x", pady=8)
        pb_row = tk.Frame(left, bg=C["panel"]); pb_row.pack(fill="x")
        self._pb = tk.Canvas(pb_row, bg=C["bord"], height=18, highlightthickness=0)
        self._pb.pack(fill="x", side="left", expand=True)
        self._bar = self._pb.create_rectangle(0,0,0,18, fill=C["red"], outline="")
        self._pct_lbl = tk.Label(pb_row, text="0%", bg=C["panel"], fg=C["dim"], font=(F,8), width=5)
        self._pct_lbl.pack(side="left", padx=4)
        self._sv = tk.StringVar(value="Bereit.")
        tk.Label(left, textvariable=self._sv, bg=C["panel"], fg=C["cyan"],
                 font=(F,9,"bold"), wraplength=380, justify="left").pack(anchor="w", pady=4)

        # Buttons
        bf = tk.Frame(left, bg=C["panel"]); bf.pack(fill="x", pady=6)
        self._go_btn = tk.Button(bf, text="▶  Importieren", command=self._start,
                                  bg=C["red"], fg="white", font=(F,10,"bold"),
                                  relief="flat", cursor="hand2", padx=16, pady=8)
        self._go_btn.pack(side="left")
        self._ab_btn = tk.Button(bf, text="⏹  Abbruch", command=self._abort,
                                  bg=C["panel"], fg=C["red2"], font=(F,9,"bold"),
                                  relief="flat", cursor="hand2", padx=12, pady=8, state="disabled")
        self._ab_btn.pack(side="left", padx=6)
        tk.Button(bf, text="✕", command=self._close,
                  bg=C["card"], fg=C["dim"], font=(F,9), relief="flat",
                  cursor="hand2", padx=10, pady=8).pack(side="left", padx=4)

        # Log
        tk.Label(right, text="Import-Log", bg=C["black"], fg=C["dim"],
                 font=(F,8,"bold")).pack(anchor="w", padx=8, pady=(8,2))
        lw = tk.Frame(right, bg=C["black"]); lw.pack(fill="both", expand=True, padx=6, pady=(0,8))
        self._log = tk.Text(lw, bg="#080810", fg="#88aa88", font=("Consolas",8),
                            wrap="word", state="disabled", relief="flat",
                            highlightthickness=0, bd=0)
        sb = tk.Scrollbar(lw, command=self._log.yview, width=8, relief="flat",
                          bg=C["card2"], troughcolor=C["black"])
        self._log.config(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y"); self._log.pack(fill="both", expand=True)
        self._log.tag_config("ok",   foreground="#44dd44")
        self._log.tag_config("err",  foreground="#dd4444")
        self._log.tag_config("inf",  foreground="#4488dd")
        self._log.tag_config("warn", foreground="#ddaa33")
        self._log.tag_config("dim",  foreground="#445544")

        self._sw("xtream")

    def _ent(self, p, var=None, **kw):
        return tk.Entry(p, textvariable=var, bg=C["inp"], fg=C["text"],
                        insertbackground=C["cyan"], font=(F,10), relief="flat",
                        highlightthickness=1, highlightbackground=C["bord2"], **kw)

    # ── Tabs ─────────────────────────────────────────────
    def _sw(self, mode):
        self._mode.set(mode)
        for k,b in self._tab_btns.items():
            b.config(bg=C["red3"] if k==mode else C["card2"],
                     fg="white"   if k==mode else C["dim"])
        for w in self._inp.winfo_children(): w.destroy()
        show_retry = mode != "xtream"  # Xtream hat eigene Retry-Logik
        if show_retry: self._retry_row.pack(fill="x")
        else:          self._retry_row.pack_forget()
        if   mode == "file":   self._tab_file()
        elif mode == "url":    self._tab_url()
        elif mode == "xtream": self._tab_xtream()

    def _tab_file(self):
        f = self._inp
        tk.Label(f, text="M3U / M3U8 / TXT / PLS / XSPF Datei:",
                 bg=C["panel"], fg=C["dim"], font=(F,9)).pack(anchor="w")
        row = tk.Frame(f, bg=C["panel"]); row.pack(fill="x", pady=2)
        self._fpath = tk.StringVar()
        self._ent(row, self._fpath).pack(side="left", fill="x", expand=True, ipady=6)
        tk.Button(row, text=" 📂 ", command=self._browse,
                  bg=C["card2"], fg=C["text"], font=(F,10),
                  relief="flat", cursor="hand2").pack(side="left", padx=(4,0))
        tk.Label(f, text="Unterstützt: M3U, M3U8, TXT (URL-Liste), PLS, XSPF",
                 bg=C["panel"], fg=C["dim"], font=(F,8)).pack(anchor="w", pady=3)

    def _tab_url(self):
        f = self._inp
        tk.Label(f, text="URL der Playlist (HTTP/HTTPS):",
                 bg=C["panel"], fg=C["dim"], font=(F,9)).pack(anchor="w")
        self._url = tk.StringVar()
        e = self._ent(f, self._url); e.pack(fill="x", ipady=6, pady=2); e.focus_set()
        tip = tk.Frame(f, bg=C["card"], padx=10, pady=6); tip.pack(fill="x", pady=4)
        tk.Label(tip, text="Beispiele:", bg=C["card"], fg=C["dim"], font=(F,8,"bold")).pack(anchor="w")
        for ex in ["http://provider.com:8080/get.php?username=X&password=Y&type=m3u_plus",
                   "http://provider.com/playlist.m3u8",
                   "https://provider.com/list.m3u"]:
            tk.Label(tip, text=f"  • {ex}", bg=C["card"], fg="#445566",
                     font=("Consolas",7)).pack(anchor="w")

    def _tab_xtream(self):
        f = self._inp

        # Info-Box oben
        info = tk.Frame(f, bg=C["card2"], padx=12, pady=8); info.pack(fill="x", pady=(0,10))
        tk.Label(info,
                 text="📡  Xtream Codes — JSON-API (zuverlässig)",
                 bg=C["card2"], fg=C["cyan"], font=(F,9,"bold")).pack(anchor="w")
        tk.Label(info,
                 text="Nutzt player_api.php statt get.php — Live, Filme & Serien werden alle erkannt.",
                 bg=C["card2"], fg=C["dim"], font=(F,8)).pack(anchor="w")

        for lbl, attr, ph, show_pw in [
            ("Server / Host (mit Port):", "_xt_host", "z.B.  http://provider.com:8080", False),
            ("Benutzername:",             "_xt_user", "username",  False),
            ("Passwort:",                 "_xt_pass", "password",  True),
        ]:
            tk.Label(f, text=lbl, bg=C["panel"], fg=C["dim"], font=(F,9)).pack(anchor="w", pady=(8,0))
            var = tk.StringVar(); setattr(self, attr, var)
            kw  = {"show":"●"} if show_pw else {}
            e   = self._ent(f, var, **kw); e.pack(fill="x", ipady=5, pady=(2,0))
            if not var.get():
                e.insert(0, ph); e.config(fg=C["dim"])
                def _fi(ev, _e=e, _v=var, _p=ph): 
                    if _v.get()==_p: _e.delete(0,"end"); _e.config(fg=C["text"])
                def _fo(ev, _e=e, _v=var, _p=ph):
                    if not _v.get(): _e.insert(0,_p); _e.config(fg=C["dim"])
                e.bind("<FocusIn>", _fi); e.bind("<FocusOut>", _fo)

        # Stream-Format
        fmt_f = tk.Frame(f, bg=C["panel"]); fmt_f.pack(fill="x", pady=(10,0))
        tk.Label(fmt_f, text="Stream-Format:", bg=C["panel"], fg=C["dim"],
                 font=(F,9)).pack(side="left")
        self._xt_fmt = tk.StringVar(value="ts")
        for v, l in [("ts","TS (empfohlen)"),("m3u8","M3U8 (HLS)"),("mp4","MP4")]:
            tk.Radiobutton(fmt_f, text=l, variable=self._xt_fmt, value=v,
                           bg=C["panel"], fg=C["text2"], selectcolor=C["red3"],
                           font=(F,9), activebackground=C["panel"]).pack(side="left", padx=8)

        # Test-Button
        tk.Button(f, text="🔌  Verbindung testen",
                  command=self._test_xtream,
                  bg=C["card2"], fg=C["teal"], font=(F,9,"bold"),
                  relief="flat", cursor="hand2", padx=12, pady=5).pack(anchor="w", pady=(10,0))

    def _browse(self):
        p = filedialog.askopenfilename(
            title="Playlist wählen",
            filetypes=[("Playlist-Dateien","*.m3u *.m3u8 *.txt *.pls *.xspf"),
                       ("Alle Dateien","*.*")])
        if p:
            self._fpath.set(p)
            self._name.set(os.path.splitext(os.path.basename(p))[0])
            self._log_a(f"Datei: {p}", "inf")

    def _test_xtream(self):
        host = getattr(self, "_xt_host", tk.StringVar()).get().strip()
        user = getattr(self, "_xt_user", tk.StringVar()).get().strip()
        pwd  = getattr(self, "_xt_pass", tk.StringVar()).get().strip()
        if not host or host.startswith("z.B"): 
            self._log_a("Host eingeben!", "err"); return
        self._log_a(f"Test: {host} ...", "inf")
        self._sv.set("Teste Verbindung...")
        def _run():
            data, err = _xtream_validate(host, user, pwd,
                                          cb=lambda m,p: self._prog(m,p))
            if err:
                self.after(0, lambda: (self._log_a(f"❌ {err}", "err"),
                                        self._sv.set(f"Fehler: {err[:60]}")))
            else:
                ui = (data or {}).get("user_info",{})
                msg = (f"✅ OK — Status: {ui.get('status','?')} | "
                       f"Max Verbindungen: {ui.get('max_connections','?')}")
                self.after(0, lambda: (self._log_a(msg,"ok"),
                                        self._sv.set("Verbindung OK!")))
        threading.Thread(target=_run, daemon=True).start()

    # ── Log ──────────────────────────────────────────────
    def _log_a(self, msg, tag="dim"):
        import datetime
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        def _u():
            self._log.config(state="normal")
            self._log.insert("end", f"[{ts}] {msg}\n", tag)
            self._log.see("end"); self._log.config(state="disabled")
        self.after(0, _u)

    def _prog(self, msg, pct=None):
        def _u():
            self._sv.set(msg)
            tag = "ok" if (pct or 0) >= 100 else ("err" if any(w in msg.lower() for w in ("fehler","error","fail")) else "inf")
            self._log_a(msg, tag)
            if pct is not None:
                p = max(0, min(100, int(pct)))
                self._pct_lbl.config(text=f"{p}%")
                w = self._pb.winfo_width() or 400
                col = C["green"] if p >= 100 else C["red"]
                self._pb.itemconfig(self._bar, fill=col)
                self._pb.coords(self._bar, 0,0, int(w*p/100), 18)
        self.after(0, _u)

    # ── Steuerung ────────────────────────────────────────
    def _busy(self, b):
        def _u():
            self._go_btn.config(state="disabled" if b else "normal",
                                 text="⏳ Läuft..." if b else "▶  Importieren")
            self._ab_btn.config(state="normal" if b else "disabled")
        self.after(0, _u)

    def _abort(self):
        self._stop.set(); self._busy(False)
        self._prog("Abgebrochen.", 0); self._log_a("Abgebrochen.", "warn")

    def _close(self):
        self._stop.set(); self.destroy()

    # ── Import ───────────────────────────────────────────
    def _start(self):
        self._stop.clear(); mode = self._mode.get()
        name = self._name.get().strip() or f"Playlist {self.slot}"
        self._busy(True)
        self._log_a(f"=== Import Slot {self.slot} — {name} | Modus: {mode} ===", "ok")

        if mode == "file":
            path = getattr(self,"_fpath",tk.StringVar()).get().strip()
            if not path or not os.path.exists(path):
                self._busy(False); self._log_a("Datei nicht gefunden.","err")
                messagebox.showerror("Fehler","Datei nicht gefunden.",parent=self); return
            threading.Thread(target=self._run_file, args=(path,name), daemon=True).start()

        elif mode == "url":
            url = getattr(self,"_url",tk.StringVar()).get().strip()
            if not url or url.startswith("http://provider"):
                self._busy(False); self._log_a("Keine URL.","err")
                messagebox.showerror("Fehler","Bitte URL eingeben.",parent=self); return
            threading.Thread(target=self._run_url, args=(url,name,self._retries.get()), daemon=True).start()

        elif mode == "xtream":
            host = getattr(self,"_xt_host",tk.StringVar()).get().strip()
            user = getattr(self,"_xt_user",tk.StringVar()).get().strip()
            pwd  = getattr(self,"_xt_pass",tk.StringVar()).get().strip()
            fmt  = getattr(self,"_xt_fmt", tk.StringVar()).get()
            if not host or host.startswith("z.B") or not user or not pwd:
                self._busy(False); self._log_a("Host/User/Passwort ausfüllen.","err")
                messagebox.showerror("Fehler","Host, Benutzername und Passwort eingeben.",parent=self); return
            src = f"xtream://{host}|{user}|{pwd}|{fmt}"
            threading.Thread(target=self._run_xtream, args=(host,user,pwd,fmt,name,src), daemon=True).start()

    # ── Worker ───────────────────────────────────────────
    def _run_file(self, path, name):
        try:
            text = read_file(path, cb=self._prog)
            if not self._stop.is_set():
                self._process(text, name, path, "file")
        except Exception as e:
            if not self._stop.is_set():
                self.after(0, lambda: self._fail(str(e)))

    def _run_url(self, url, name, retries):
        self._log_a(f"URL: {url[:100]}", "inf")
        last_err = ""
        for att in range(1, retries+1):
            if self._stop.is_set(): return
            if att > 1:
                d = min(att*3, 20)
                self._prog(f"Versuch {att}/{retries} — warte {d}s...", 2)
                for _ in range(d*2):
                    if self._stop.is_set(): return
                    time.sleep(0.5)
            self._prog(f"Download (Versuch {att}/{retries})...", 5)
            try:
                text = fetch_url(url, cb=self._prog, max_attempts=1)
                if text and len(text) > 80:
                    self._log_a(f"Download OK: {len(text):,} Zeichen", "ok")
                    if not self._stop.is_set():
                        self._process(text, name, url, "url")
                    return
                last_err = f"Zu kurz: {len(text) if text else 0}"
            except Exception as e:
                last_err = str(e)
                self._log_a(f"Versuch {att} Fehler: {last_err[:100]}", "err")

            # PS-Fallback
            if not self._stop.is_set() and sys.platform=="win32":
                self._prog("PowerShell-Fallback...", 8)
                raw = _ps_get(url, timeout=60)
                if raw and len(raw) > 80:
                    text = _decode(raw)
                    self._log_a(f"PowerShell OK: {len(text):,}", "ok")
                    if not self._stop.is_set():
                        self._process(text, name, url, "url")
                    return

        if not self._stop.is_set():
            self.after(0, lambda: self._fail(
                f"Alle {retries} Versuche fehlgeschlagen.\n\nLetzter Fehler:\n{last_err}\n\n"
                "Tipps:\n• URL prüfen\n• Xtream-Tab verwenden (zuverlässiger!)"))

    def _run_xtream(self, host, user, pwd, fmt, name, src):
        try:
            channels, exp = import_xtream(host, user, pwd, fmt, cb=self._prog)
            if not channels:
                self.after(0, lambda: self._fail("Keine Kanäle erhalten."))
                return
            if not self._stop.is_set():
                self._save(channels, name, src, "xtream", exp)
        except Exception as e:
            if not self._stop.is_set():
                err = str(e)
                self.after(0, lambda: self._fail(
                    f"{err}\n\n"
                    "Tipps:\n"
                    "• Host-Format prüfen: http://server.com:8080\n"
                    "• Benutzername und Passwort korrekt?\n"
                    "• Server erreichbar? (Verbindung testen)"))

    def _process(self, text, name, src, stype):
        if self._stop.is_set(): return
        fmt = detect_format(text)
        self._prog(f"Format: {fmt.upper()}", 82)
        try:
            channels = parse_any(text, fmt, cb=self._prog)
        except Exception as e:
            self.after(0, lambda: self._fail(f"Parse-Fehler: {e}")); return
        if not channels:
            self.after(0, lambda: self._fail(
                "Keine Kanäle gefunden!\n\nMögliche Ursachen:\n"
                "• Falsches Format / leere Playlist\n"
                "• Authentifizierungsfehler\n"
                "• Für Xtream: bitte den 'Xtream Codes' Tab verwenden!")); return
        exp = find_expiry(text)
        if not self._stop.is_set():
            self._save(channels, name, src, stype, exp)

    def _save(self, channels, name, src, stype, exp=""):
        if self._stop.is_set(): return
        self._prog(f"Speichere {len(channels):,} Kanäle...", 92)
        pid   = pl_save(self.slot, name, src, stype, exp)
        count = ch_save(pid, channels, cb=self._prog)

        by_cat = {}
        for ch in channels:
            c = ch.get("category","live"); by_cat[c] = by_cat.get(c,0)+1
        live   = by_cat.get("live",0)
        vod    = by_cat.get("video",0)
        series = by_cat.get("series",0)

        self._log_a(f"Gesamt: {count:,} | Live: {live:,} | Filme: {vod:,} | Serien: {series:,}", "ok")
        self._prog("✅ Import abgeschlossen!", 100)

        msg = (f"✅  Import erfolgreich!\n\n"
               f"📺  Live-Sender:  {live:,}\n"
               f"🎬  Filme:        {vod:,}\n"
               f"🎭  Serien:       {series:,}\n"
               f"────────────────────\n"
               f"📋  Gesamt:       {count:,}")
        if exp: msg += f"\n\n📅  Gültig bis: {exp}"

        self.after(0, lambda: self._finish(msg))

    def _finish(self, msg):
        self._busy(False)
        messagebox.showinfo("Import erfolgreich", msg, parent=self)
        self.destroy(); self.on_ok()

    def _fail(self, msg):
        self._busy(False)
        self._log_a(f"FEHLER: {msg[:200]}", "err")
        messagebox.showerror("Import fehlgeschlagen", msg, parent=self)


# ═══════════════════════════════════════════════════════════
# INTERNER PLAYER — mpv --wid=HWND (kein externes Fenster)
# ═══════════════════════════════════════════════════════════

import ctypes, ctypes.wintypes

def find_mpv():
    import shutil
    candidates = [
        shutil.which("mpv"),
        shutil.which("mpv.exe"),
        os.path.join(HOME, "mpv", "mpv.exe"),
        os.path.join(HOME, "mpv.exe"),
        (os.path.dirname(sys.executable) + os.sep + "mpv.exe") if getattr(sys,"frozen",False) else None,
        os.path.dirname(os.path.abspath(__file__)) + os.sep + "mpv.exe",
        r"C:\Program Files\mpv\mpv.exe",
        r"C:\Program Files (x86)\mpv\mpv.exe",
        r"C:\mpv\mpv.exe",
        os.path.join(os.path.expanduser("~"),"scoop","apps","mpv","current","mpv.exe"),
        os.path.join(os.path.expanduser("~"),"scoop","shims","mpv.exe"),
    ]
    for p in candidates:
        if p and os.path.isfile(p):
            return p
    return None

def _mpv_target_dir():
    """Zielordner für mpv.exe"""
    d = os.path.join(HOME, "mpv")
    os.makedirs(d, exist_ok=True)
    return d

def _install_via_powershell(cb=None):
    """
    Lädt mpv.exe via PowerShell herunter.
    PowerShell nutzt Windows-eigenen HTTP-Stack (mit Proxy-Support).
    Versucht mehrere Download-URLs nacheinander.
    """
    if sys.platform != "win32": return None
    if cb: cb("🔌 PowerShell-Download startet...", 10)

    target_dir = _mpv_target_dir()
    zip_path   = os.path.join(target_dir, "_mpv_dl.zip")
    mpv_exe    = os.path.join(target_dir, "mpv.exe")

    # Download-URLs — von zuverlässig zu alternativ
    URLS = [
        # Offizielle shinchiro Windows-Builds (GitHub Releases)
        "https://github.com/shinchiro/mpv-winbuild-cmake/releases/download/20240901/mpv-x86_64-20240901-git-9c06afe.zip",
        # Alternativer Build
        "https://github.com/zhongfly/mpv-winbuild/releases/download/2024-02-11-12-23/mpv-x86_64-20240211-git-97be37b.zip",
        # Nightly via nightly.link
        "https://nightly.link/shinchiro/mpv-winbuild-cmake/workflows/daily/master/mpv-x86_64-latest.zip",
        # SourceForge Mirror
        "https://sourceforge.net/projects/mpv-player-windows/files/64bit/mpv-x86_64-20240128-git.7z/download",
    ]

    for i, url in enumerate(URLS):
        if cb: cb(f"⬇  Lade mpv herunter... ({i+1}/{len(URLS)})", 15 + i*15)

        # PowerShell-Skript: Download + Extraktion in einem Schritt
        ps_script = f"""
$ProgressPreference = 'SilentlyContinue'
$ErrorActionPreference = 'Stop'
try {{
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $wc = New-Object System.Net.WebClient
    $wc.Headers.Add('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)')
    $wc.DownloadFile('{url}', '{zip_path}')
    Write-Output "DOWNLOAD_OK:$((Get-Item '{zip_path}').Length)"
}} catch {{
    Write-Output "DOWNLOAD_FAIL:$_"
}}
"""
        try:
            r = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive",
                 "-ExecutionPolicy", "Bypass", "-Command", ps_script],
                capture_output=True, text=True, timeout=120,
                creationflags=CNW if sys.platform=="win32" else 0)
            out = r.stdout.strip()
        except Exception as e:
            if cb: cb(f"⚠ PowerShell Fehler: {str(e)[:50]}", 15+i*15)
            continue

        if "DOWNLOAD_OK" in out and os.path.isfile(zip_path) and os.path.getsize(zip_path) > 100000:
            size_mb = os.path.getsize(zip_path) / 1048576
            if cb: cb(f"📦 Entpacke mpv.exe... ({size_mb:.1f} MB)", 75)

            # Entpacken via PowerShell
            ps_extract = f"""
$ProgressPreference = 'SilentlyContinue'
$ErrorActionPreference = 'Stop'
try {{
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead('{zip_path}')
    foreach ($entry in $zip.Entries) {{
        if ($entry.Name -eq 'mpv.exe') {{
            $dst = '{mpv_exe}'
            [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $dst, $true)
            Write-Output "EXTRACT_OK:$dst"
            break
        }}
    }}
    $zip.Dispose()
}} catch {{
    Write-Output "EXTRACT_FAIL:$_"
}}
"""
            try:
                r2 = subprocess.run(
                    ["powershell", "-NoProfile", "-NonInteractive",
                     "-ExecutionPolicy", "Bypass", "-Command", ps_extract],
                    capture_output=True, text=True, timeout=60,
                    creationflags=CNW if sys.platform=="win32" else 0)
                out2 = r2.stdout.strip()
            except Exception as e:
                if cb: cb(f"⚠ Entpack-Fehler: {str(e)[:50]}", 78)
                continue

            # Aufräumen
            try: os.remove(zip_path)
            except: pass

            if "EXTRACT_OK" in out2 and os.path.isfile(mpv_exe):
                if cb: cb(f"✅ mpv.exe installiert!", 95)
                return mpv_exe
            else:
                if cb: cb(f"⚠ mpv.exe nicht in ZIP gefunden ({out2[:60]})", 78)
        else:
            if cb: cb(f"⚠ URL {i+1} fehlgeschlagen: {out[:60]}", 15+i*15)
            try: os.remove(zip_path)
            except: pass

    return None


def _install_via_winget(cb=None):
    """Installiert mpv via winget (Microsoft Store)."""
    if cb: cb("🔧 Versuche winget...", 5)
    try:
        r = subprocess.run(
            ["winget","install","mpv.mpv",
             "--accept-source-agreements","--accept-package-agreements","--silent"],
            capture_output=True, text=True, timeout=120,
            creationflags=CNW if sys.platform=="win32" else 0)
        if r.returncode == 0:
            if cb: cb("✅ winget erfolgreich!", 90)
            time.sleep(2)
            p = find_mpv()
            if p: return p
    except FileNotFoundError: pass
    except subprocess.TimeoutExpired: pass
    return None


def _install_via_urllib(cb=None):
    """Lädt mpv via Python urllib (Fallback)."""
    target_dir = _mpv_target_dir()
    zip_path   = os.path.join(target_dir, "_mpv_dl.zip")
    mpv_exe    = os.path.join(target_dir, "mpv.exe")

    URLS = [
        "https://github.com/shinchiro/mpv-winbuild-cmake/releases/download/20240901/mpv-x86_64-20240901-git-9c06afe.zip",
        "https://github.com/zhongfly/mpv-winbuild/releases/download/2024-02-11-12-23/mpv-x86_64-20240211-git-97be37b.zip",
        "https://nightly.link/shinchiro/mpv-winbuild-cmake/workflows/daily/master/mpv-x86_64-latest.zip",
    ]
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE

    for i, url in enumerate(URLS):
        if cb: cb(f"⬇  Python-Download ({i+1}/{len(URLS)})...", 20+i*10)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, context=ctx, timeout=60) as r:
                total = int(r.headers.get("Content-Length") or 0)
                chunks = []; done = 0; t0 = time.time()
                while True:
                    chunk = r.read(131072)
                    if not chunk: break
                    chunks.append(chunk); done += len(chunk)
                    if cb and total > 0:
                        pct = 20 + i*10 + int(done/total*30)
                        spd = done/max(0.1, time.time()-t0)/1024
                        cb(f"⬇  {done//1048576} MB  ({spd:.0f} KB/s)", pct)
            with open(zip_path,"wb") as f: f.write(b"".join(chunks))
            if cb: cb("📦 Entpacke...", 75)
            with zipfile.ZipFile(zip_path,"r") as z:
                for name in z.namelist():
                    if name.endswith("mpv.exe"):
                        with z.open(name) as zf, open(mpv_exe,"wb") as of:
                            of.write(zf.read())
                        break
            try: os.remove(zip_path)
            except: pass
            if os.path.isfile(mpv_exe):
                if cb: cb("✅ mpv.exe heruntergeladen!", 95)
                return mpv_exe
        except Exception as e:
            if cb: cb(f"⚠ urllib fehlgeschlagen: {str(e)[:60]}", 20+i*10)
            try: os.remove(zip_path)
            except: pass
    return None


def install_mpv_auto(cb=None):
    """
    Installiert mpv automatisch — versucht alle Methoden:
    1. winget  (schnell, kein Download)
    2. PowerShell WebClient  (Windows HTTP-Stack, Proxy-Support)
    3. Python urllib  (Fallback)
    """
    if cb: cb("🔍 Starte Installation...", 2)

    # 1. winget
    result = _install_via_winget(cb)
    if result: return result

    # 2. PowerShell (Windows-eigener HTTP-Stack)
    if cb: cb("🔌 PowerShell-Download (Windows HTTP)...", 10)
    result = _install_via_powershell(cb)
    if result: return result

    # 3. Python urllib
    if cb: cb("🐍 Python-Download...", 20)
    result = _install_via_urllib(cb)
    if result: return result

    return None


class InternalPlayer:
    """
    Spielt Video DIREKT in einen Tkinter-Canvas via mpv --wid=HWND.
    Kein separates Fenster moeglich.
    """
    def __init__(self):
        self._exe   = find_mpv()
        self._hwnd  = 0
        self._proc  = None
        self._pipe  = None
        self._seq   = 0
        self._vol   = cfg_get("vol", 80)
        self._state = "idle"
        self._pos   = 0.0
        self._dur   = 0.0

    @property
    def ok(self):           return bool(self._exe)
    @property
    def exe(self):          return self._exe or ""
    @property
    def backend(self):      return f"mpv (intern)" if self._exe else "kein Player"
    def refresh(self):      self._exe = find_mpv()

    def attach(self, canvas_widget):
        canvas_widget.update_idletasks()
        hwnd = canvas_widget.winfo_id()
        self._hwnd = hwnd

    def reattach(self, canvas_widget):
        self.attach(canvas_widget)

    def play(self, url, start_ms=0, cat="live", title=""):
        self._stop_proc()
        if not self._exe:   self._state="error_no_player"; return False
        if not self._hwnd:  self._state="error";           return False

        self._seq += 1; my_seq = self._seq
        self._state = "opening"; self._pos = 0.0; self._dur = 0.0

        pipe_name = r"\\.\pipe\exiptv-{}-{}".format(os.getpid(), my_seq)

        args = [
            self._exe, url,
            f"--wid={self._hwnd}",
            "--no-terminal",
            "--keep-open=always",
            "--force-window=yes",
            f"--input-ipc-server={pipe_name}",
            f"--volume={self._vol}",
            f"--title={title or 'EX IPTV'}",
            "--osd-level=0",
            f"--user-agent={UA}",
            "--tls-verify=no",
            "--network-timeout=15",
            "--input-default-bindings=no",
            "--input-cursor=no",
            "--no-border",
            "--autofit=100%x100%",
        ]
        if cat == "live":
            args += [
                "--cache=yes","--cache-secs=5","--demuxer-max-bytes=16MiB",
                "--stream-lavf-o=reconnect=1,reconnect_on_network_error=1,"
                "reconnect_streamed=1,reconnect_delay_max=5",
            ]
        else:
            args += [
                "--cache=yes","--demuxer-max-bytes=128MiB","--demuxer-readahead-secs=20",
                "--stream-lavf-o=reconnect=1,reconnect_on_network_error=1",
            ]
        if start_ms > 0:
            args.append(f"--start={start_ms/1000:.3f}")

        try:
            self._proc = subprocess.Popen(
                args, creationflags=CNW if sys.platform=="win32" else 0)
        except Exception:
            self._state = "error"; return False

        threading.Thread(target=self._ipc_loop, args=(pipe_name,my_seq), daemon=True).start()
        threading.Thread(target=self._watch,    args=(my_seq,),          daemon=True).start()
        return True

    def stop(self):     self._stop_proc(); self._pos=0.0; self._dur=0.0
    def pause(self):    self._send("cycle","pause")
    def volume(self,v): self._vol=max(0,min(200,int(v))); self._send("set_property","volume",self._vol)
    def seek(self,ms):  self._send("seek",ms/1000.0,"absolute+exact")
    def get_time(self): return int(self._pos*1000)
    def get_length(self): return int(self._dur*1000)
    def is_alive(self): return self._proc is not None and self._proc.poll() is None
    def state(self):
        if not self.is_alive() and self._state not in ("idle","ended","stopped","error","error_no_player"):
            return "ended"
        return self._state

    def _stop_proc(self):
        self._seq += 1
        if self._proc:
            try: self._proc.terminate()
            except: pass
            self._proc = None
        self._pipe = None; self._state = "idle"

    def _watch(self, seq):
        if not self._proc: return
        self._proc.wait()
        if self._seq == seq and self._state not in ("idle","stopped"):
            self._state = "ended"

    def _send(self, *args):
        if not self._pipe or sys.platform != "win32": return
        try:
            k32  = ctypes.windll.kernel32
            data = (json.dumps({"command":list(args)})+"\n").encode()
            w    = ctypes.c_ulong(0)
            k32.WriteFile(self._pipe, data, len(data), ctypes.byref(w), None)
        except: pass

    def _ipc_loop(self, pipe_name, my_seq):
        if sys.platform != "win32": return
        k32 = ctypes.windll.kernel32
        deadline = time.time()+10; h=None
        while time.time()<deadline and self._seq==my_seq:
            hh = k32.CreateFileW(pipe_name, 0xC0000000, 0, None, 3, 0, None)
            if hh and hh != ctypes.c_void_p(-1).value: h=hh; break
            time.sleep(0.1)
        if not h or self._seq!=my_seq:
            if h: k32.CloseHandle(h); return
        self._pipe = h
        for idx,prop in enumerate(["time-pos","duration","pause","core-idle","eof-reached"],1):
            d=(json.dumps({"command":["observe_property",idx,prop]})+"\n").encode()
            w=ctypes.c_ulong(0); k32.WriteFile(h,d,len(d),ctypes.byref(w),None)
        buf=b""
        while self._seq==my_seq and self.is_alive():
            av=ctypes.c_ulong(0)
            if k32.PeekNamedPipe(h,None,0,None,ctypes.byref(av),None) and av.value>0:
                n=min(av.value,32768); raw=ctypes.create_string_buffer(n); rd=ctypes.c_ulong(0)
                k32.ReadFile(h,raw,n,ctypes.byref(rd),None); buf+=raw.raw[:rd.value]
                while b"\n" in buf:
                    line,buf=buf.split(b"\n",1)
                    if line:
                        try: self._on(json.loads(line))
                        except: pass
            else: time.sleep(0.05)
        try: k32.CloseHandle(h)
        except: pass
        if self._pipe==h: self._pipe=None

    def _on(self, d):
        e=d.get("event")
        if e=="property-change":
            n,v=d.get("name"),d.get("data")
            if   n=="time-pos"   and v is not None: self._pos=float(v)
            elif n=="duration"   and v is not None: self._dur=float(v)
            elif n=="pause"      and v is not None: self._state="paused" if v else "playing"
            elif n=="core-idle"  and v is not None:
                if v and self._state=="playing": self._state="buffering"
                elif not v and self._state not in("paused","ended","error"): self._state="playing"
            elif n=="eof-reached" and v: self._state="ended"
        elif e=="playback-restart": self._state="playing"
        elif e=="end-file":
            r=d.get("reason","")
            self._state="ended" if r=="eof" else("error" if r in("error","unknown") else self._state)


# Aliases
VlcPlayer      = InternalPlayer
ExternalPlayer = InternalPlayer
VLC_OK         = False
VLC_DIR        = None

def make_player():
    return InternalPlayer()

MpvPlayer = make_player


# ═══════════════════════════════════════════════════════════
# PLAYER-INSTALLER DIALOG
# ═══════════════════════════════════════════════════════════
class MpvInstallerDlg(tk.Toplevel):
    """
    Installiert mpv vollautomatisch.
    Methoden: 1. winget  2. PowerShell-Download  3. Python urllib
    Zeigt Fortschritt + Log in Echtzeit.
    """
    def __init__(self, root, on_done):
        super().__init__(root)
        self.on_done = on_done
        self.title("mpv Installation")
        self.configure(bg=C["panel"])
        self.resizable(False, False)
        self.grab_set()
        self.protocol("WM_DELETE_WINDOW", lambda: None)
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"600x460+{(sw-600)//2}+{(sh-460)//2}")
        self._build()
        self.after(300, self._start)

    def _build(self):
        # Header
        hf = tk.Frame(self, bg=C["red3"], height=52)
        hf.pack(fill="x"); hf.pack_propagate(False)
        tk.Label(hf, text="  mpv wird automatisch installiert",
                 bg=C["red3"], fg="white", font=(F,12,"bold")).pack(side="left", padx=14, pady=14)

        body = tk.Frame(self, bg=C["panel"]); body.pack(fill="both", expand=True, padx=20, pady=14)

        tk.Label(body,
                 text="Video-Player mpv wird installiert (3 Methoden werden versucht).",
                 bg=C["panel"], fg=C["text2"], font=(F,9)).pack(anchor="w", pady=(0,8))

        # Fortschrittsbalken
        self.pb  = tk.Canvas(body, bg=C["bord"], height=20, highlightthickness=0)
        self.pb.pack(fill="x")
        self.bar = self.pb.create_rectangle(0, 0, 0, 20, fill=C["red"], outline="")
        self.pct = tk.Label(body, text="0%", bg=C["panel"], fg=C["dim"], font=(F,8))
        self.pct.pack(anchor="e", pady=2)

        # Aktueller Status
        self.msg = tk.StringVar(value="Starte...")
        tk.Label(body, textvariable=self.msg, bg=C["panel"], fg=C["cyan"],
                 font=(F,10,"bold"), wraplength=560, justify="left").pack(anchor="w", pady=(2,6))

        # Log
        lf = tk.Frame(body, bg=C["card"]); lf.pack(fill="both", expand=True)
        self.log_txt = tk.Text(lf, bg=C["card"], fg=C["dim"], font=("Consolas",8),
                               height=8, wrap="word", state="disabled",
                               relief="flat", highlightthickness=0, bd=0)
        sb = tk.Scrollbar(lf, command=self.log_txt.yview, width=8, relief="flat")
        self.log_txt.config(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.log_txt.pack(fill="both", expand=True, padx=6, pady=4)

        # Button-Frame (bleibt leer bis fertig)
        self.btn_frame = tk.Frame(self, bg=C["panel"])
        self.btn_frame.pack(fill="x", padx=20, pady=8)

    def _log(self, txt):
        def _u():
            self.log_txt.config(state="normal")
            self.log_txt.insert("end", txt + "\n")
            self.log_txt.see("end")
            self.log_txt.config(state="disabled")
        self.after(0, _u)

    def _progress(self, msg, pct=0):
        def _u():
            self.msg.set(msg)
            self.pct.config(text=f"{int(pct)}%")
            w = self.pb.winfo_width() or 560
            self.pb.coords(self.bar, 0, 0, int(w * pct / 100), 20)
            self._log(f"[{int(pct):3d}%] {msg}")
        self.after(0, _u)

    def _start(self):
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        exe = install_mpv_auto(cb=self._progress)
        if exe:
            self.after(0, lambda: self._done(exe))
        else:
            self.after(0, self._fail)

    def _done(self, exe):
        self.msg.set("mpv installiert!")
        self.pct.config(text="100%")
        w = self.pb.winfo_width() or 560
        self.pb.coords(self.bar, 0, 0, w, 20)
        self.pb.itemconfig(self.bar, fill=C["green"])
        self._log(f"Pfad: {exe}")
        tk.Button(self.btn_frame, text="Fertig - App neu laden",
                  command=lambda: (self.destroy(), self.on_done(exe)),
                  bg=C["green"], fg=C["black"], font=(F,11,"bold"),
                  relief="flat", cursor="hand2", padx=20, pady=10).pack(fill="x")

    def _fail(self):
        self.msg.set("Alle Methoden fehlgeschlagen.")
        self.pb.itemconfig(self.bar, fill=C["red2"])
        self._log("--- FEHLGESCHLAGEN ---")
        info = (
            "Bitte manuell installieren:\n"
            "\n"
            "1. Windows Terminal als Administrator oeffnen\n"
            "2. Eingeben:  winget install mpv.mpv\n"
            "3. App neu starten\n"
            "\n"
            f"ODER: mpv.exe nach {os.path.join(HOME, 'mpv', '')} kopieren"
        )
        tk.Label(self.btn_frame, text=info,
                 bg=C["panel"], fg=C["yellow"], font=("Consolas",9),
                 justify="left").pack(anchor="w", pady=4)
        tk.Button(self.btn_frame, text="Schliessen",
                  command=lambda: (self.destroy(), self.on_done(None)),
                  bg=C["card2"], fg=C["text"], font=(F,10),
                  relief="flat", cursor="hand2", padx=16, pady=6).pack(anchor="e", pady=4)

# ═══════════════════════════════════════════════════════════
# KANAL-LISTE
# ═══════════════════════════════════════════════════════════
class ChanList(tk.Frame):
    def __init__(self,parent,cat,on_select):
        super().__init__(parent,bg=C["side"])
        self.cat=cat; self.on_select=on_select
        self._pid=None; self._rows=[]; self._grps=[]; self._cur_grp="Alle"
        self._after=None; self._drag_idx=None; self._filt=[]; self._build()

    def _order_key(self): return f"grp_{self.cat}_{self._pid}"
    def _load_order(self,grps):
        saved=cfg_get(self._order_key(),[])
        valid=[g for g in saved if g in grps]
        return valid+[g for g in grps if g not in valid]
    def _save_order(self):
        if self._pid: cfg_set(self._order_key(),list(self._grps))

    def _build(self):
        sf=tk.Frame(self,bg=C["side"],padx=5,pady=5); sf.pack(fill="x")
        self.sv=tk.StringVar(); self.sv.trace("w",self._later)
        self._se=tk.Entry(sf,textvariable=self.sv,bg=C["inp"],fg=C["text"],
                          insertbackground=C["cyan"],font=(F,9),relief="flat",
                          highlightthickness=1,highlightbackground=C["bord2"])
        self._se.pack(fill="x",ipady=5)
        self._se.insert(0,"🔍 Suchen..."); self._se.config(fg=C["dim"])
        self._se.bind("<FocusIn>",  lambda e:(self._se.delete(0,"end"),self._se.config(fg=C["text"])) if self._se.get().startswith("🔍") else None)
        self._se.bind("<FocusOut>", lambda e:(self._se.insert(0,"🔍 Suchen..."),self._se.config(fg=C["dim"])) if not self._se.get() else None)
        self.cnt=tk.Label(self,text="",bg=C["side"],fg=C["dim"],font=(F,8)); self.cnt.pack(anchor="w",padx=6)
        cols=tk.Frame(self,bg=C["side"]); cols.pack(fill="both",expand=True)
        gf=tk.Frame(cols,bg=C["panel"],width=148); gf.pack(side="left",fill="y"); gf.pack_propagate(False)
        gh=tk.Frame(gf,bg=C["red3"],height=26); gh.pack(fill="x")
        tk.Label(gh,text=" 📂 Gruppen",bg=C["red3"],fg="white",font=(F,8,"bold")).pack(side="left",pady=3)
        gsb=tk.Scrollbar(gf,width=5,relief="flat"); gsb.pack(side="right",fill="y")
        self.glb=tk.Listbox(gf,bg=C["panel"],fg=C["text2"],selectbackground=C["red3"],
                            selectforeground="white",font=(F,9),relief="flat",borderwidth=0,
                            activestyle="none",yscrollcommand=gsb.set,highlightthickness=0,width=17)
        self.glb.pack(side="left",fill="both",expand=True); gsb.config(command=self.glb.yview)
        self.glb.bind("<<ListboxSelect>>",self._grp_click)
        self.glb.bind("<MouseWheel>",lambda e:self.glb.yview_scroll(-1*(e.delta//120),"units"))
        self.glb.bind("<ButtonPress-1>",self._ds); self.glb.bind("<B1-Motion>",self._dm); self.glb.bind("<ButtonRelease-1>",self._de)
        tk.Frame(cols,bg=C["red3"],width=2).pack(side="left",fill="y")
        cf=tk.Frame(cols,bg=C["side"]); cf.pack(side="left",fill="both",expand=True)
        chh=tk.Frame(cf,bg=C["inp"],height=26); chh.pack(fill="x"); chh.pack_propagate(False)
        self.ch_hdr=tk.Label(chh,text=" 📺 Alle",bg=C["inp"],fg=C["dim"],font=(F,8,"bold")); self.ch_hdr.pack(side="left",pady=3)
        csb=tk.Scrollbar(cf,width=5,relief="flat"); csb.pack(side="right",fill="y")
        self.clb=tk.Listbox(cf,bg=C["side"],fg=C["text"],selectbackground=C["red3"],
                            selectforeground="white",font=(F,9),relief="flat",borderwidth=0,
                            activestyle="none",yscrollcommand=csb.set,highlightthickness=0)
        self.clb.pack(side="left",fill="both",expand=True); csb.config(command=self.clb.yview)
        self.clb.bind("<<ListboxSelect>>",self._ch_click)
        self.clb.bind("<MouseWheel>",lambda e:self.clb.yview_scroll(-1*(e.delta//120),"units"))

    def load(self,pid): self._pid=pid; threading.Thread(target=self._bg,daemon=True).start()
    def _bg(self):
        rows=ch_load(self._pid)
        if self.cat: rows=[r for r in rows if r.get("cat")==self.cat]
        grps=sorted(set(r.get("grp","") for r in rows if r.get("grp","")))
        self.after(0,lambda:self._loaded(rows,grps))
    def _loaded(self,rows,grps):
        self._rows=rows; self._grps=self._load_order(grps)
        self._rebuild(len(rows)); self._cur_grp="Alle"; self._fill()
    def _rebuild(self,n=None):
        n=n if n is not None else len(self._rows)
        self.glb.delete(0,"end"); self.glb.insert("end",f"  Alle  ({n:,})")
        for g in self._grps: self.glb.insert("end",f"  {g}")
        self.glb.selection_set(0)
    def _ds(self,e): idx=self.glb.nearest(e.y); self._drag_idx=idx if idx>0 else None
    def _dm(self,e):
        if self._drag_idx is None: return
        tgt=self.glb.nearest(e.y)
        if tgt<=0 or tgt==self._drag_idx: return
        i1,i2=self._drag_idx-1,tgt-1
        if 0<=i1<len(self._grps) and 0<=i2<len(self._grps):
            self._grps[i1],self._grps[i2]=self._grps[i2],self._grps[i1]
            self._rebuild(); self.glb.selection_set(tgt); self._drag_idx=tgt
    def _de(self,e):
        if self._drag_idx is not None: self._save_order()
        self._drag_idx=None
    def _grp_click(self,e):
        s=self.glb.curselection()
        if not s: return
        idx=s[0]
        self._cur_grp="Alle" if idx==0 else (self._grps[idx-1] if idx-1<len(self._grps) else "Alle")
        self.ch_hdr.config(text=f" 📺 {'Alle' if self._cur_grp=='Alle' else self._cur_grp[:20]}")
        self._fill()
    def _later(self,*a):
        if self._after: self.after_cancel(self._after)
        self._after=self.after(200,self._fill)
    def _fill(self):
        q=self.sv.get().strip().lower()
        if q.startswith("🔍"): q=""
        rows=self._rows if self._cur_grp=="Alle" else [r for r in self._rows if r.get("grp","")==self._cur_grp]
        if q: rows=[r for r in rows if q in r.get("name","").lower()]
        self._filt=rows[:3000]; self.clb.delete(0,"end")
        self.cnt.config(text=f"  {len(self._filt):,} Kanäle")
        for r in self._filt: self.clb.insert("end",f"  {r.get('name','')}")
    def _ch_click(self,e):
        s=self.clb.curselection()
        if s and s[0]<len(self._filt): self.on_select(self._filt[s[0]])

# ═══════════════════════════════════════════════════════════
# SERIEN-LISTE
# ═══════════════════════════════════════════════════════════
class SeriesList(tk.Frame):
    def __init__(self,parent,on_select):
        super().__init__(parent,bg=C["side"])
        self._pid=None; self._series={}; self._on=on_select
        self._names=[]; self._seasons=[]; self._eps=[]; self._cur=None; self._curs=None
        self._after=None; self._build()

    def _build(self):
        sf=tk.Frame(self,bg=C["side"],padx=5,pady=5); sf.pack(fill="x")
        self.sv=tk.StringVar(); self.sv.trace("w",self._later)
        se=tk.Entry(sf,textvariable=self.sv,bg=C["inp"],fg=C["text"],
                    insertbackground=C["cyan"],font=(F,9),relief="flat",
                    highlightthickness=1,highlightbackground=C["bord2"])
        se.pack(fill="x",ipady=5)
        se.insert(0,"🔍 Serie suchen..."); se.config(fg=C["dim"])
        se.bind("<FocusIn>",  lambda e:(se.delete(0,"end"),se.config(fg=C["text"])) if se.get().startswith("🔍") else None)
        se.bind("<FocusOut>", lambda e:(se.insert(0,"🔍 Serie suchen..."),se.config(fg=C["dim"])) if not se.get() else None)
        cols=tk.Frame(self,bg=C["side"]); cols.pack(fill="both",expand=True)
        specs=[
            (C["panel"],148,"#1a0030",C["purple"]," 🎭 Serien","lb1",C["purple2"]),
            (C["card"],118,"#0d1a30",C["cyan"]," 📅 Staffeln","lb2",C["cyan2"]),
            (C["side"],0,"#0d2010",C["green"]," 🎬 Folgen","lb3",C["teal"]),
        ]
        for cbg,cw,hbg,hfg,htxt,lid,sbg in specs:
            kw={"width":cw} if cw else {}
            cf=tk.Frame(cols,bg=cbg,**kw)
            if cw: cf.pack(side="left",fill="y"); cf.pack_propagate(False)
            else: cf.pack(side="left",fill="both",expand=True)
            hf=tk.Frame(cf,bg=hbg,height=26); hf.pack(fill="x")
            tk.Label(hf,text=htxt,bg=hbg,fg=hfg,font=(F,8,"bold")).pack(side="left",pady=3)
            sb=tk.Scrollbar(cf,width=5,relief="flat"); sb.pack(side="right",fill="y")
            lb=tk.Listbox(cf,bg=cbg,fg=C["text2"],selectbackground=sbg,
                          selectforeground="white",font=(F,9),relief="flat",borderwidth=0,
                          activestyle="none",yscrollcommand=sb.set,highlightthickness=0)
            lb.pack(side="left",fill="both",expand=True); sb.config(command=lb.yview)
            lb.bind("<MouseWheel>",lambda e,l=lb:l.yview_scroll(-1*(e.delta//120),"units"))
            setattr(self,lid,lb)
            if cw: tk.Frame(cols,bg=sbg,width=2).pack(side="left",fill="y")
        self.lb1.bind("<<ListboxSelect>>",self._s1)
        self.lb2.bind("<<ListboxSelect>>",self._s2)
        self.lb3.bind("<<ListboxSelect>>",self._s3)

    def load(self,pid): self._pid=pid; threading.Thread(target=self._bg,daemon=True).start()
    def _bg(self):
        rows=ch_load(self._pid); rows=[r for r in rows if r.get("cat")=="series"]
        tree={}
        for r in rows:
            sn=r.get("sn","") or r.get("name",""); se=r.get("se","01")
            if not sn: continue
            if sn not in tree: tree[sn]={}
            if se not in tree[sn]: tree[sn][se]=[]
            tree[sn][se].append(r)
        for sn in tree:
            for se in tree[sn]: tree[sn][se].sort(key=lambda r:r.get("ep",""))
        self.after(0,lambda:self._loaded(tree))
    def _loaded(self,tree): self._series=tree; self._fs()
    def _later(self,*a):
        if self._after: self.after_cancel(self._after)
        self._after=self.after(250,self._fs)
    def _fs(self):
        q=self.sv.get().strip().lower()
        if q.startswith("🔍"): q=""
        names=sorted(self._series.keys())
        if q: names=[n for n in names if q in n.lower()]
        self._names=names; self.lb1.delete(0,"end")
        for n in names:
            cnt=sum(len(v) for v in self._series[n].values())
            self.lb1.insert("end",f"  {n}  ({cnt})")
        self.lb2.delete(0,"end"); self.lb3.delete(0,"end"); self._eps=[]; self._cur=None; self._curs=None
    def _s1(self,e):
        s=self.lb1.curselection()
        if not s or s[0]>=len(self._names): return
        self._cur=self._names[s[0]]
        seasons=sorted(self._series[self._cur].keys()); self._seasons=seasons
        self.lb2.delete(0,"end"); self.lb3.delete(0,"end"); self._eps=[]
        for se in seasons: self.lb2.insert("end",f"  Staffel {se}  ({len(self._series[self._cur][se])})")
    def _s2(self,e):
        s=self.lb2.curselection()
        if not s or not self._cur or s[0]>=len(self._seasons): return
        self._curs=self._seasons[s[0]]; eps=self._series[self._cur][self._curs]; self._eps=eps
        self.lb3.delete(0,"end")
        for r in eps: self.lb3.insert("end",f"  E{r.get('ep','')}  {r.get('name','')}")
    def _s3(self,e):
        s=self.lb3.curselection()
        if s and s[0]<len(self._eps): self._on(self._eps[s[0]])
    def navigate_to(self,sn,season=None):
        if not sn: return
        names=sorted(self._series.keys()); self._names=names
        idx=next((i for i,n in enumerate(names) if n==sn),None)
        if idx is None: idx=next((i for i,n in enumerate(names) if sn.lower() in n.lower()),None)
        if idx is None: return
        self.lb1.selection_clear(0,"end"); self.lb1.selection_set(idx); self.lb1.see(idx)
        self._cur=names[idx]; seasons=sorted(self._series[self._cur].keys()); self._seasons=seasons
        self.lb2.delete(0,"end"); self.lb3.delete(0,"end"); self._eps=[]
        for se in seasons: self.lb2.insert("end",f"  Staffel {se}  ({len(self._series[self._cur][se])})")
        if season and season in seasons:
            si=seasons.index(season); self.lb2.selection_set(si); self.lb2.see(si); self._s2(None)


# ═══════════════════════════════════════════════════════════
# NOW PLAYING PANEL — mpv --wid Video direkt im Canvas
# ═══════════════════════════════════════════════════════════
class NowPlayingPanel(tk.Frame):
    def __init__(self, parent, player, app):
        super().__init__(parent, bg=C["black"])
        self.pl   = player
        self.app  = app
        self._ch  = None
        self._rc  = 0
        self._rct = None
        self._vol = cfg_get("vol", 80)
        self._seeking   = False
        self._last_save = 0.0
        self._build()
        self._poll()

    def _build(self):
        # Header
        hf = tk.Frame(self, bg=C["hdr"], height=52)
        hf.pack(fill="x", side="top"); hf.pack_propagate(False)
        lf = tk.Frame(hf, bg=C["hdr"]); lf.pack(side="left", padx=12, fill="y")
        self.ch_lbl = tk.Label(lf, text="Kein Kanal", bg=C["hdr"], fg=C["dim"], font=(F,13,"bold"))
        self.ch_lbl.pack(anchor="w", pady=(12,0))
        self.st_lbl = tk.Label(lf, text="", bg=C["hdr"], fg=C["dim"], font=(F,9))
        self.st_lbl.pack(anchor="w")
        rf = tk.Frame(hf, bg=C["hdr"]); rf.pack(side="right", padx=12, fill="y")
        self.res_lbl = tk.Label(rf, text="", bg=C["hdr"], fg=C["cyan"], font=(F,9,"bold"))
        self.res_lbl.pack(anchor="e", pady=8)
        self.be_lbl = tk.Label(rf, text=self.pl.backend, bg=C["hdr"], fg=C["dim"], font=(F,7))
        self.be_lbl.pack(anchor="e")

        # Video-Canvas (HWND fuer mpv --wid)
        self.video = tk.Canvas(self, bg=C["black"], highlightthickness=0, cursor="arrow")
        self.video.pack(fill="both", expand=True, side="top")
        self._overlay = tk.Label(self.video, text="TV  EX IPTV\n\nKanal anklicken",
                                  bg=C["black"], fg="#303050", font=(F,12), justify="center")
        self._overlay.place(relx=.5, rely=.5, anchor="center")
        self.video.bind("<Configure>", self._on_resize)

        # Seekbar
        skf = tk.Frame(self, bg=C["card"], height=42)
        skf.pack(fill="x", side="top"); skf.pack_propagate(False)
        def _sb(t, ms):
            return tk.Button(skf, text=t, command=lambda: self._skip(ms),
                bg=C["card"], fg=C["text2"], font=(F,8,"bold"), relief="flat",
                cursor="hand2", padx=8, activebackground=C["card2"])
        _sb("<<30s",-30000).pack(side="left",padx=(8,2),pady=10)
        _sb("<<10s",-10000).pack(side="left",padx=2,pady=10)
        self.pos_lbl = tk.Label(skf,text="--:--",bg=C["card"],fg=C["text2"],font=(F,8),width=6)
        self.pos_lbl.pack(side="left",padx=4)
        self.sk = tk.Canvas(skf, bg=C["bord"], height=8, cursor="hand2", highlightthickness=0)
        self.sk.pack(side="left", fill="x", expand=True, pady=17)
        self.sk_bar  = self.sk.create_rectangle(0,0,0,8, fill=C["red"], outline="")
        self.sk_knob = self.sk.create_oval(-6,-4,6,12, fill=C["red2"], outline="", state="hidden")
        self.sk.bind("<ButtonPress-1>",   lambda e: setattr(self,"_seeking",True))
        self.sk.bind("<B1-Motion>",        self._sk_drag)
        self.sk.bind("<ButtonRelease-1>",  self._sk_rel)
        self.sk.bind("<Enter>", lambda e: self.sk.itemconfig(self.sk_knob,state="normal"))
        self.sk.bind("<Leave>", lambda e: self.sk.itemconfig(self.sk_knob,state="hidden"))
        self.dur_lbl = tk.Label(skf,text="--:--",bg=C["card"],fg=C["text2"],font=(F,8),width=6)
        self.dur_lbl.pack(side="left",padx=4)
        _sb("10s>>",10000).pack(side="left",padx=2,pady=10)
        _sb("30s>>",30000).pack(side="left",padx=(2,8),pady=10)

        # Controls
        cf = tk.Frame(self, bg=C["panel"], height=52)
        cf.pack(fill="x", side="top"); cf.pack_propagate(False)
        lc = tk.Frame(cf, bg=C["panel"]); lc.pack(side="left",padx=8,fill="y")
        self.pause_btn = tk.Button(lc, text="||  Pause", command=self.pl.pause,
            bg=C["card2"], fg=C["cyan"], font=(F,10,"bold"), relief="flat",
            cursor="hand2", padx=14, pady=8, activebackground=C["bord2"])
        self.pause_btn.pack(side="left",padx=4,pady=10)
        tk.Button(lc, text="[]  Stop", command=self._stop,
            bg=C["card"], fg=C["dim"], font=(F,10,"bold"), relief="flat",
            cursor="hand2", padx=12, pady=8, activebackground=C["bord2"]).pack(side="left",padx=4,pady=10)
        rc = tk.Frame(cf, bg=C["panel"]); rc.pack(side="right",padx=12,fill="y")
        self.tl = tk.Label(rc,text="",bg=C["panel"],fg=C["dim"],font=(F,8))
        self.tl.pack(anchor="e",pady=(14,0))
        vr = tk.Frame(rc,bg=C["panel"]); vr.pack(anchor="e")
        tk.Label(vr,text="Vol",bg=C["panel"],fg=C["dim"],font=(F,8)).pack(side="left",padx=(0,4))
        self.vsc = tk.Scale(vr,from_=0,to=200,orient="horizontal",length=90,
                            bg=C["panel"],fg=C["text"],highlightthickness=0,bd=0,
                            troughcolor=C["bord2"],activebackground=C["red"],
                            showvalue=False,command=self._vol_ch)
        self.vsc.set(self._vol); self.vsc.pack(side="left",padx=2)
        self.vl = tk.Label(vr,text=f"{self._vol}%",bg=C["panel"],fg=C["dim"],font=(F,8),width=4)
        self.vl.pack(side="left")

    def _on_resize(self, _=None):
        if self._ch and self.pl.is_alive():
            self.pl.attach(self.video)

    def play(self, ch, start_ms=0):
        if self._ch: self._save_pos()
        self._ch = ch; self._rc = 0
        if self._rct:
            try: self.after_cancel(self._rct)
            except: pass
            self._rct = None
        cat  = ch.get("cat", ch.get("category","live"))
        name = ch.get("name","")
        self.ch_lbl.config(text=f"  {name}", fg=C["text"])
        self.st_lbl.config(text="  ... Verbinde...", fg=C["yellow"])
        self.res_lbl.config(text="")
        self._overlay.place_forget()
        # Embed HWND then play after 100ms
        self.video.update_idletasks()
        self.pl.attach(self.video)
        self.after(100, self._do_play, ch, start_ms, cat, name)

    def _do_play(self, ch, start_ms, cat, name):
        ok = self.pl.play(ch["url"], start_ms=start_ms, cat=cat, title=name)
        self.pl.volume(self._vol)
        if not ok:
            self.st_lbl.config(text="  mpv fehlt -> Einstellungen", fg=C["red2"])
            self._overlay.config(text="mpv nicht gefunden\n\nEinstellungen -> mpv installieren", fg=C["red2"])
            self._overlay.place(relx=.5, rely=.5, anchor="center")

    def _save_pos(self):
        if not self._ch: return
        if self._ch.get("cat","live") not in ("video","series"): return
        pos=self.pl.get_time(); dur=self.pl.get_length()
        if pos>0: threading.Thread(target=cw_update,args=(self._ch,pos,dur),daemon=True).start()

    def _stop(self):
        self._save_pos()
        if self._rct:
            try: self.after_cancel(self._rct)
            except: pass
            self._rct=None
        self.pl.stop(); self._ch=None
        self.ch_lbl.config(text="Kein Kanal",fg=C["dim"])
        self.st_lbl.config(text=""); self.res_lbl.config(text=""); self.tl.config(text="")
        self.pos_lbl.config(text="--:--"); self.dur_lbl.config(text="--:--")
        self.sk.coords(self.sk_bar,0,0,0,8)
        self._overlay.config(text="TV  EX IPTV\n\nKanal anklicken",fg="#303050")
        self._overlay.place(relx=.5,rely=.5,anchor="center")

    def _sk_drag(self,e):
        w=self.sk.winfo_width() or 1; x=max(0,min(e.x,w))
        self.sk.coords(self.sk_knob,x-6,-4,x+6,12)
        self.sk.coords(self.sk_bar,0,0,x,8)
        dur=self.pl.get_length()
        if dur>0: self.pos_lbl.config(text=fmt_time(int(x/w*dur)))

    def _sk_rel(self,e):
        self._seeking=False
        w=self.sk.winfo_width() or 1
        dur=self.pl.get_length()
        if dur>0: self.pl.seek(int(max(0,min(e.x,w))/w*dur))

    def _skip(self,ms):
        pos=self.pl.get_time(); dur=self.pl.get_length()
        self.pl.seek(max(0,min(pos+ms,max(0,dur-500))))

    def _vol_ch(self,v):
        self._vol=int(v); self.pl.volume(self._vol)
        self.vl.config(text=f"{self._vol}%"); cfg_set("vol",self._vol)

    def _poll(self):
        if self._ch:
            s=self.pl.state()
            if s=="playing":
                if self._rc>0: self._rc=0
                self.st_lbl.config(text="  Spielt",fg=C["green"])
                pos=self.pl.get_time(); dur=self.pl.get_length()
                if not self._seeking and dur>0:
                    w=self.sk.winfo_width()
                    if w>1:
                        bw=int(pos/dur*w)
                        self.sk.coords(self.sk_bar,0,0,bw,8)
                        self.sk.coords(self.sk_knob,bw-6,-4,bw+6,12)
                    self.pos_lbl.config(text=fmt_time(pos))
                    self.dur_lbl.config(text=fmt_time(dur))
                    self.tl.config(text=f"Verbleibend: {fmt_time(dur-pos)}")
                if self._ch.get("cat","live") in("video","series") and pos>0:
                    now=time.time()
                    if now-self._last_save>15: self._last_save=now; self._save_pos()
            elif s=="buffering": self.st_lbl.config(text="  Puffert...",fg=C["yellow"])
            elif s=="opening":   self.st_lbl.config(text="  Oeffnet...",fg=C["yellow"])
            elif s=="paused":    self.st_lbl.config(text="  Pause",     fg=C["dim"])
            elif s=="ended":     self.st_lbl.config(text="  Ende",      fg=C["dim"])
            elif s in("error","error_no_player"):
                if s=="error_no_player":
                    self.st_lbl.config(text="  mpv fehlt",fg=C["red2"])
                elif self._rc<5:
                    self._rc+=1; delay=min(3000+self._rc*2000,15000)
                    self.st_lbl.config(text=f"  Reconnect {self._rc}/5...",fg=C["orange"])
                    if self._ch:
                        cc=self._ch.copy()
                        self._rct=self.after(delay,lambda:self.play(cc) if self._ch else None)
                else:
                    self.st_lbl.config(text="  Verbindung verloren",fg=C["red2"])
        self.after(1000,self._poll)


# ═══════════════════════════════════════════════════════════
# CONTINUE WATCHING
# ═══════════════════════════════════════════════════════════
class ContinueWatchingPage(tk.Frame):
    def __init__(self,parent,on_play):
        super().__init__(parent,bg=C["bg"]); self.on_play=on_play; self._build()
    def _build(self):
        hf=tk.Frame(self,bg=C["red3"],height=50); hf.pack(fill="x"); hf.pack_propagate(False)
        tk.Label(hf,text="  ▶  Continue Watching",bg=C["red3"],fg="white",font=(F,13,"bold")).pack(side="left",padx=12,pady=10)
        tk.Button(hf,text="↺",command=self.refresh,bg=C["red3"],fg="white",font=(F,11),relief="flat",cursor="hand2",padx=10).pack(side="right",padx=12,pady=12)
        cv=tk.Canvas(self,bg=C["bg"],highlightthickness=0); sb=tk.Scrollbar(self,orient="vertical",command=cv.yview)
        cv.configure(yscrollcommand=sb.set); sb.pack(side="right",fill="y"); cv.pack(fill="both",expand=True)
        self.inn=tk.Frame(cv,bg=C["bg"]); w=cv.create_window((0,0),window=self.inn,anchor="nw")
        self.inn.bind("<Configure>",lambda e:cv.configure(scrollregion=cv.bbox("all")))
        cv.bind("<Configure>",lambda e:cv.itemconfig(w,width=e.width))
        cv.bind("<MouseWheel>",lambda e:cv.yview_scroll(-1*(e.delta//120),"units"))
        self.refresh()
    def refresh(self):
        for w in self.inn.winfo_children(): w.destroy()
        items=cw_get_all()
        if not items:
            tk.Label(self.inn,text="\n\n▶  Noch nichts gesehen.",bg=C["bg"],fg=C["dim"],font=(F,12)).pack(pady=80); return
        for item in items: self._card(item)
    def _card(self,item):
        pos=item.get("pos_ms",0); dur=item.get("dur_ms",0); pct=int(pos/dur*100) if dur>0 else 0
        cat=item.get("cat","video")
        cc={"video":C["purple"],"series":C["teal"],"live":C["red"]}.get(cat,C["dim"])
        ct={"video":"🎬","series":"🎭","live":"📺"}.get(cat,"")
        card=tk.Frame(self.inn,bg=C["card"],padx=14,pady=10); card.pack(fill="x",padx=16,pady=4)
        inf=tk.Frame(card,bg=C["card"]); inf.pack(side="left",fill="x",expand=True)
        tr=tk.Frame(inf,bg=C["card"]); tr.pack(fill="x")
        tk.Label(tr,text=ct,bg=C["card"],fg=cc,font=(F,11,"bold")).pack(side="left",padx=(0,8))
        name=item.get("name","")
        if item.get("sn") and item.get("se") and item.get("ep"):
            name=f"{item['sn']}  S{item['se']}E{item['ep']}"
        tk.Label(tr,text=name,bg=C["card"],fg=C["text"],font=(F,10,"bold")).pack(side="left")
        pb=tk.Canvas(inf,bg=C["bord"],height=5,highlightthickness=0); pb.pack(fill="x",pady=(6,2))
        self.inn.after(50,lambda pb=pb,p=pct:pb.create_rectangle(0,0,max(1,int(pb.winfo_reqwidth()*p/100)),5,fill=C["red"],outline=""))
        tr2=tk.Frame(inf,bg=C["card"]); tr2.pack(fill="x")
        tk.Label(tr2,text=f"  {fmt_time(pos)} / {fmt_time(dur)}  ({pct}%)",bg=C["card"],fg=C["dim"],font=(F,8)).pack(side="left")
        bf=tk.Frame(card,bg=C["card"]); bf.pack(side="right",padx=6)
        tk.Button(bf,text="▶  Weiterschauen",command=lambda i=item,p=pos:self.on_play(i,p),
                  bg=C["red"],fg="white",font=(F,9,"bold"),relief="flat",cursor="hand2",padx=12,pady=6).pack(pady=2)
        tk.Button(bf,text="✕",command=lambda u=item.get("url",""):self._rm(u),
                  bg=C["card"],fg=C["dim"],font=(F,8),relief="flat",cursor="hand2",padx=8).pack()
    def _rm(self,url): cw_remove(url); self.refresh()

# ═══════════════════════════════════════════════════════════
# SUCHE
# ═══════════════════════════════════════════════════════════
class SearchPage(tk.Frame):
    def __init__(self,parent,on_play):
        super().__init__(parent,bg=C["bg"]); self.on_play=on_play; self._pid=None; self._after=None; self._results=[]; self._build()
    def _build(self):
        hf=tk.Frame(self,bg=C["red3"],height=50); hf.pack(fill="x"); hf.pack_propagate(False)
        tk.Label(hf,text="  🔍  Globale Suche",bg=C["red3"],fg="white",font=(F,13,"bold")).pack(side="left",padx=12,pady=10)
        sf=tk.Frame(self,bg=C["bg"]); sf.pack(fill="x",padx=16,pady=12)
        self.sv=tk.StringVar(); self.sv.trace("w",self._later)
        se=tk.Entry(sf,textvariable=self.sv,bg=C["inp"],fg=C["text"],insertbackground=C["cyan"],
                    font=(F,13),relief="flat",highlightthickness=2,highlightbackground=C["red3"])
        se.pack(fill="x",ipady=8); se.focus_set()
        ff=tk.Frame(self,bg=C["bg"]); ff.pack(fill="x",padx=16,pady=(0,6))
        self.cv=tk.StringVar(value="all")
        for v,l,col in [("all","Alle","white"),("live","📺 Live",C["red"]),("video","🎬 Filme",C["purple"]),("series","🎭 Serien",C["teal"])]:
            tk.Radiobutton(ff,text=l,variable=self.cv,value=v,bg=C["bg"],fg=col,selectcolor=C["card"],
                           font=(F,9),activebackground=C["bg"],command=self._later).pack(side="left",padx=10)
        self.cnt=tk.Label(self,text="",bg=C["bg"],fg=C["dim"],font=(F,8)); self.cnt.pack(anchor="w",padx=16)
        rf=tk.Frame(self,bg=C["bg"]); rf.pack(fill="both",expand=True,padx=16,pady=(4,12))
        sb=tk.Scrollbar(rf,width=8,relief="flat"); sb.pack(side="right",fill="y")
        self.lb=tk.Listbox(rf,bg=C["side"],fg=C["text"],selectbackground=C["red3"],selectforeground="white",
                           font=(F,10),relief="flat",borderwidth=0,activestyle="none",
                           yscrollcommand=sb.set,highlightthickness=0)
        self.lb.pack(side="left",fill="both",expand=True); sb.config(command=self.lb.yview)
        self.lb.bind("<<ListboxSelect>>",self._sel)
        self.lb.bind("<MouseWheel>",lambda e:self.lb.yview_scroll(-1*(e.delta//120),"units"))
    def set_pid(self,pid): self._pid=pid
    def _later(self,*a):
        if self._after: self.after_cancel(self._after)
        self._after=self.after(250,self._search)
    def _search(self):
        q=self.sv.get().strip().lower()
        if not q or not self._pid: self.lb.delete(0,"end"); self.cnt.config(text=""); self._results=[]; return
        threading.Thread(target=self._bg,args=(q,),daemon=True).start()
    def _bg(self,q):
        rows=ch_load(self._pid); cat=self.cv.get()
        if cat!="all": rows=[r for r in rows if r.get("cat")==cat]
        words=q.split()
        res=[r for r in rows if all(w in (r.get("name","")+" "+r.get("grp","")).lower() for w in words)][:500]
        self.after(0,lambda:self._show(res))
    def _show(self,results):
        self._results=results; self.lb.delete(0,"end")
        self.cnt.config(text=f"  {len(results):,} Treffer")
        ic={"live":"📺","video":"🎬","series":"🎭"}
        for r in results: self.lb.insert("end",f"  {ic.get(r.get('cat','live'),'📺')}  {r.get('name','')}   [{r.get('grp','')}]")
    def _sel(self,e):
        s=self.lb.curselection()
        if s and s[0]<len(self._results): self.on_play(self._results[s[0]])

# ═══════════════════════════════════════════════════════════
# EINSTELLUNGEN
# ═══════════════════════════════════════════════════════════
class SettingsPage(tk.Frame):
    """Player-Einstellungen (mpv). Playlists -> ProviderPage."""
    def __init__(self, parent, app):
        super().__init__(parent, bg=C["bg"])
        self.app = app
        cv = tk.Canvas(self, bg=C["bg"], highlightthickness=0)
        sb = tk.Scrollbar(self, orient="vertical", command=cv.yview)
        cv.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y"); cv.pack(fill="both", expand=True)
        self.inn = tk.Frame(cv, bg=C["bg"])
        w = cv.create_window((0,0), window=self.inn, anchor="nw")
        self.inn.bind("<Configure>", lambda e: cv.configure(scrollregion=cv.bbox("all")))
        cv.bind("<Configure>", lambda e: cv.itemconfig(w, width=e.width))
        cv.bind("<MouseWheel>", lambda e: cv.yview_scroll(-1*(e.delta//120), "units"))
        self._build()

    def _build(self):
        hf = tk.Frame(self.inn, bg=C["red3"], height=52)
        hf.pack(fill="x"); hf.pack_propagate(False)
        tk.Label(hf, text="  ⚙  Einstellungen",
                 bg=C["red3"], fg="white", font=(F,14,"bold")).pack(side="left", padx=16, pady=14)

        # ── Video-Backend ──────────────────────────────────────
        self._sec("🎬  Video-Backend")
        pl = self.app.player; pl.refresh()
        tf = tk.Frame(self.inn, bg=C["card"], padx=16, pady=14)
        tf.pack(fill="x", padx=16, pady=(0,6))
        mpv_p = find_mpv()
        if mpv_p:
            row = tk.Frame(tf, bg=C["card"]); row.pack(fill="x")
            tk.Label(row, text="✅", bg=C["card"], fg=C["green"],
                     font=(F,14)).pack(side="left", padx=(0,10))
            inf = tk.Frame(row, bg=C["card"]); inf.pack(side="left", fill="x", expand=True)
            tk.Label(inf, text="mpv (integrierter Player)",
                     bg=C["card"], fg=C["text"], font=(F,10,"bold")).pack(anchor="w")
            tk.Label(inf, text=mpv_p,
                     bg=C["card"], fg=C["dim"], font=("Consolas",8)).pack(anchor="w")
            tk.Label(inf,
                     text="Video wird direkt in die App eingebettet. Kein externes Fenster.",
                     bg=C["card"], fg=C["teal"], font=(F,8)).pack(anchor="w", pady=(2,0))
            tk.Button(tf, text="↺  Pfad-Suche erneuern",
                      command=self._refresh_mpv,
                      bg=C["card2"], fg=C["text"], font=(F,9), relief="flat",
                      cursor="hand2", padx=10, pady=4).pack(anchor="w", pady=(10,0))
        else:
            row = tk.Frame(tf, bg=C["card"]); row.pack(fill="x")
            tk.Label(row, text="❌", bg=C["card"], fg=C["red2"],
                     font=(F,14)).pack(side="left", padx=(0,10))
            inf = tk.Frame(row, bg=C["card"]); inf.pack(side="left", fill="x", expand=True)
            tk.Label(inf, text="mpv nicht gefunden",
                     bg=C["card"], fg=C["red2"], font=(F,10,"bold")).pack(anchor="w")
            tk.Label(inf, text="mpv ist erforderlich für eingebettete Video-Wiedergabe.",
                     bg=C["card"], fg=C["dim"], font=(F,8)).pack(anchor="w")
            tk.Button(tf, text="⬇  mpv automatisch installieren",
                      command=self._install_mpv,
                      bg=C["red"], fg="white", font=(F,10,"bold"),
                      relief="flat", cursor="hand2", padx=16, pady=8).pack(anchor="w", pady=(10,4))
            tk.Label(tf, text="Oder manuell: winget install mpv.mpv",
                     bg=C["card"], fg=C["dim"], font=(F,8)).pack(anchor="w")

        # ── App-Info ───────────────────────────────────────────
        self._sec("ℹ  App-Info")
        af = tk.Frame(self.inn, bg=C["card"], padx=16, pady=12)
        af.pack(fill="x", padx=16, pady=(0,6))
        for lbl, val in [("Version", "EX IPTV Player v9.7"),
                          ("Engine",  "Python + Tkinter + mpv --wid"),
                          ("Daten",    HOME)]:
            row = tk.Frame(af, bg=C["card"]); row.pack(fill="x", pady=2)
            tk.Label(row, text=f"{lbl}:", bg=C["card"], fg=C["dim"],
                     font=(F,8), width=10, anchor="w").pack(side="left")
            tk.Label(row, text=val, bg=C["card"], fg=C["text2"],
                     font=("Consolas",8)).pack(side="left")

    def _sec(self, t):
        f = tk.Frame(self.inn, bg=C["bg"]); f.pack(fill="x", padx=16, pady=(14,3))
        tk.Label(f, text=t, bg=C["bg"], fg=C["red2"], font=(F,10,"bold")).pack(anchor="w")
        tk.Frame(f, bg=C["red3"], height=1).pack(fill="x", pady=(3,0))

    def _install_mpv(self):
        MpvInstallerDlg(self, self._on_mpv_done)

    def _on_mpv_done(self, exe):
        self.app.player.refresh()
        for w in self.inn.winfo_children(): w.destroy()
        self._build()

    def _refresh_mpv(self):
        self.app.player.refresh()
        for w in self.inn.winfo_children(): w.destroy()
        self._build()

    def refresh(self): pass  # kein Playlist-State mehr hier


# ═══════════════════════════════════════════════════════════
# ANBIETER-SEITE (Provider Management)
# ═══════════════════════════════════════════════════════════
class ProviderPage(tk.Frame):
    """
    Dedizierte Anbieter-Verwaltung — wie im modernen IPTV-App-Style.
    Jeder Anbieter = eine Karte mit:
      • Name, Typ, Kanalzahl, Zuletzt-aktualisiert
      • Toggle (aktiv/inaktiv)
      • Buttons: Umbenennen | Aktualisieren | Löschen
      • Fehlermeldung falls letzter Import gescheitert
    """
    def __init__(self, parent, app):
        super().__init__(parent, bg=C["bg"])
        self.app = app
        self._build_chrome()
        self._build_list()

    # ── Gerüst ────────────────────────────────────────────────
    def _build_chrome(self):
        # Header-Leiste
        hf = tk.Frame(self, bg=C["bg"], height=64)
        hf.pack(fill="x"); hf.pack_propagate(False)
        tk.Label(hf, text="Anbieter",
                 bg=C["bg"], fg=C["text"], font=(F,18,"bold")).pack(side="left", padx=20, pady=16)
        tk.Button(hf, text="+ Anbieter hinzufügen",
                  command=self._add,
                  bg=C["red"], fg="white", font=(F,10,"bold"),
                  relief="flat", cursor="hand2", padx=16, pady=8,
                  activebackground=C["red3"]).pack(side="right", padx=20, pady=12)
        tk.Frame(self, bg=C["bord"], height=1).pack(fill="x")

        # Scroll-Container
        cv = tk.Canvas(self, bg=C["bg"], highlightthickness=0)
        sb = tk.Scrollbar(self, orient="vertical", command=cv.yview)
        cv.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y"); cv.pack(fill="both", expand=True)
        self._scroll_cv = cv
        self._list_frame = tk.Frame(cv, bg=C["bg"])
        self._win_id = cv.create_window((0,0), window=self._list_frame, anchor="nw")
        self._list_frame.bind("<Configure>",
            lambda e: cv.configure(scrollregion=cv.bbox("all")))
        cv.bind("<Configure>",
            lambda e: cv.itemconfig(self._win_id, width=e.width))
        cv.bind("<MouseWheel>",
            lambda e: cv.yview_scroll(-1*(e.delta//120), "units"))

    def _build_list(self):
        for w in self._list_frame.winfo_children():
            w.destroy()
        pls = pl_all()
        if not pls:
            self._build_empty()
            return
        for pl in pls:
            self._build_card(pl)
        tk.Frame(self._list_frame, bg=C["bg"], height=20).pack()

    def _build_empty(self):
        f = tk.Frame(self._list_frame, bg=C["bg"])
        f.pack(expand=True, pady=60)
        tk.Label(f, text="📋", bg=C["bg"], fg=C["dim"], font=(F,40)).pack()
        tk.Label(f, text="Noch keine Anbieter",
                 bg=C["bg"], fg=C["text"], font=(F,14,"bold")).pack(pady=(8,4))
        tk.Label(f, text="Klicke auf '+ Anbieter hinzufügen' um deine erste Playlist zu laden.",
                 bg=C["bg"], fg=C["dim"], font=(F,10)).pack()
        tk.Button(f, text="+ Anbieter hinzufügen",
                  command=self._add,
                  bg=C["red"], fg="white", font=(F,11,"bold"),
                  relief="flat", cursor="hand2", padx=20, pady=10).pack(pady=16)

    # ── Provider-Karte ────────────────────────────────────────
    def _build_card(self, pl):
        slot    = pl["slot"]
        name    = pl.get("name", f"Playlist {slot}")
        src     = pl.get("src", "")
        stype   = pl.get("stype","url")
        exp     = pl.get("exp","")
        is_act  = (self.app.slot == slot)

        # Kanal-Anzahl aus Cache
        ch_count = 0
        if pl.get("pid"):
            chs = ch_load(pl["pid"])
            ch_count = len(chs)

        # Typ-Beschriftung
        type_lbl = {
            "url":    "URL-Playlist",
            "file":   "Lokale Datei",
            "xtream": "Xtream-Zugang",
        }.get(stype, stype.upper())

        # Karte
        card = tk.Frame(self._list_frame, bg=C["card"],
                        highlightthickness=1,
                        highlightbackground=C["red3"] if is_act else C["bord"])
        card.pack(fill="x", padx=20, pady=(12,0))

        # ── Karten-Body ─────────────────────────────────────
        body = tk.Frame(card, bg=C["card"], padx=20, pady=16)
        body.pack(fill="x")

        # Linke Spalte: Info
        left = tk.Frame(body, bg=C["card"]); left.pack(side="left", fill="x", expand=True)

        # Name + Toggle (Toggle rechts)
        name_row = tk.Frame(left, bg=C["card"]); name_row.pack(fill="x")
        name_lbl = tk.Label(name_row, text=name,
                            bg=C["card"], fg=C["text"], font=(F,13,"bold"))
        name_lbl.pack(side="left")
        if is_act:
            tk.Label(name_row, text="  AKTIV",
                     bg=C["red3"], fg="white", font=(F,7,"bold"),
                     padx=6, pady=2).pack(side="left", padx=8)

        # Toggle (rechte Seite)
        toggle_var = tk.BooleanVar(value=is_act)
        self._build_toggle(body, toggle_var,
                           on_cmd=lambda s=slot: self._activate(s),
                           off_cmd=lambda s=slot: self._deactivate(s))

        # Meta-Info
        meta_parts = [type_lbl]
        if ch_count > 0:
            meta_parts.append(f"{ch_count:,} Sender")
        else:
            meta_parts.append("0 Sender")
        if exp:
            meta_parts.append(f"Gültig bis {exp}")
        tk.Label(left, text=" · ".join(meta_parts),
                 bg=C["card"], fg=C["dim"], font=(F,9)).pack(anchor="w", pady=(3,0))

        # Quelle (gekürzt)
        src_short = ("…" + src[-80:]) if len(src) > 82 else src
        tk.Label(left, text=src_short,
                 bg=C["card"], fg="#444466", font=("Consolas",7),
                 wraplength=600, justify="left").pack(anchor="w", pady=(1,0))

        # ── Trennlinie + Button-Leiste ───────────────────────
        tk.Frame(card, bg=C["bord"], height=1).pack(fill="x")
        btn_row = tk.Frame(card, bg=C["card2"], padx=12, pady=8)
        btn_row.pack(fill="x")

        def _btn(text, cmd, bg=C["card"], fg=C["text"], bold=False):
            return tk.Button(btn_row, text=text, command=cmd,
                             bg=bg, fg=fg,
                             font=(F,9,"bold" if bold else "normal"),
                             relief="flat", cursor="hand2",
                             padx=12, pady=5,
                             activebackground=C["bord2"])

        _btn("↺  Umbenennen", lambda s=slot,n=name: self._rename(s,n)).pack(side="left", padx=(0,4))
        _btn("⟳  Aktualisieren", lambda s=slot: self._refresh_pl(s),
             bg=C["card2"], fg=C["text"]).pack(side="left", padx=4)
        _btn("＋  Neu laden / Ersetzen", lambda s=slot: self._import(s),
             bg=C["card2"], fg=C["cyan"]).pack(side="left", padx=4)
        _btn("🗑  Löschen", lambda s=slot: self._delete(s),
             bg=C["card"], fg=C["red2"]).pack(side="right")

        # ── Fehlermeldung (falls vorhanden) ─────────────────
        err = cfg_get(f"pl_err_{slot}", "")
        if err:
            ef = tk.Frame(card, bg="#1a0505", padx=16, pady=8)
            ef.pack(fill="x")
            tk.Label(ef,
                     text=f"⚠  {err}",
                     bg="#1a0505", fg="#ee4444", font=(F,8),
                     wraplength=700, justify="left").pack(anchor="w")

    def _build_toggle(self, parent, var, on_cmd, off_cmd):
        """Moderner Toggle-Switch."""
        w, h = 48, 26
        cv = tk.Canvas(parent, width=w, height=h,
                        bg=C["card"], highlightthickness=0, cursor="hand2")
        cv.pack(side="right", padx=(8,0))

        def _draw():
            cv.delete("all")
            on = var.get()
            bg_col = C["red"] if on else C["bord2"]
            cv.create_rounded_rect = lambda: None  # dummy
            # Hintergrund (Pill)
            cv.create_oval(2, 2, h-2, h-2, fill=bg_col, outline="")
            cv.create_oval(w-h+2, 2, w-2, h-2, fill=bg_col, outline="")
            cv.create_rectangle(h//2, 2, w-h//2, h-2, fill=bg_col, outline="")
            # Knopf
            kx = w-h//2-1 if on else h//2+1
            cv.create_oval(kx-h//2+3, 3, kx+h//2-3, h-3, fill="white", outline="")

        _draw()

        def _toggle(e=None):
            var.set(not var.get())
            _draw()
            if var.get(): on_cmd()
            else:         off_cmd()

        cv.bind("<Button-1>", _toggle)

    # ── Aktionen ─────────────────────────────────────────────
    def _add(self):
        # Nächsten freien Slot finden
        used = {p["slot"] for p in pl_all()}
        slot = next((s for s in range(1,21) if s not in used), 1)
        ImportDlg(self, slot, self._on_import_done)

    def _import(self, slot):
        ImportDlg(self, slot, self._on_import_done)

    def _on_import_done(self):
        cfg_set(f"pl_err_{self.app.slot}", "")  # Reset Fehler
        if not self.app.slot:
            pls = pl_all()
            if pls:
                self.app.slot = pls[0]["slot"]
                cfg_set("slot", self.app.slot)
        self.refresh()
        self.app.reload()

    def _activate(self, slot):
        self.app.slot = slot
        cfg_set("slot", slot)
        self.refresh()
        self.app.reload()

    def _deactivate(self, slot):
        # Keinen aktiven Slot -> ersten anderen wählen
        pls = [p for p in pl_all() if p["slot"] != slot]
        if pls:
            self.app.slot = pls[0]["slot"]
            cfg_set("slot", self.app.slot)
        else:
            self.app.slot = None
            cfg_set("slot", None)
        self.refresh()
        self.app.reload()

    def _rename(self, slot, current_name):
        dlg = tk.Toplevel(self)
        dlg.title("Umbenennen"); dlg.configure(bg=C["panel"])
        dlg.resizable(False, False); dlg.grab_set()
        sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
        dlg.geometry(f"400x160+{(sw-400)//2}+{(sh-160)//2}")
        tk.Label(dlg, text="Neuer Name:", bg=C["panel"],
                 fg=C["dim"], font=(F,9)).pack(anchor="w", padx=20, pady=(16,2))
        var = tk.StringVar(value=current_name)
        e = tk.Entry(dlg, textvariable=var, bg=C["inp"], fg=C["text"],
                     insertbackground=C["cyan"], font=(F,11), relief="flat",
                     highlightthickness=1, highlightbackground=C["red"])
        e.pack(fill="x", padx=20, ipady=6); e.select_range(0,"end"); e.focus_set()
        bf = tk.Frame(dlg, bg=C["panel"]); bf.pack(pady=12)
        def _ok():
            n = var.get().strip()
            if n:
                with dbconn() as c:
                    c.execute("UPDATE playlists SET name=? WHERE slot=?", (n, slot))
                dlg.destroy(); self.refresh()
        tk.Button(bf, text="✓ Speichern", command=_ok,
                  bg=C["red"], fg="white", font=(F,10,"bold"),
                  relief="flat", cursor="hand2", padx=14, pady=6).pack(side="left", padx=4)
        tk.Button(bf, text="Abbrechen", command=dlg.destroy,
                  bg=C["card2"], fg=C["dim"], font=(F,10),
                  relief="flat", cursor="hand2", padx=14, pady=6).pack(side="left", padx=4)
        dlg.bind("<Return>", lambda e: _ok())
        dlg.bind("<Escape>", lambda e: dlg.destroy())

    def _refresh_pl(self, slot):
        """Playlist neu laden (gleiche URL/Datei wie beim letzten Import)."""
        pl = pl_get(slot)
        if not pl:
            messagebox.showerror("Fehler", "Anbieter nicht gefunden.", parent=self)
            return
        # Direkt neu importieren mit vorhandenen Daten
        dlg = tk.Toplevel(self)
        dlg.title("Aktualisieren"); dlg.configure(bg=C["panel"])
        dlg.resizable(False, False); dlg.grab_set()
        sw, sh = dlg.winfo_screenwidth(), dlg.winfo_screenheight()
        dlg.geometry(f"480x180+{(sw-480)//2}+{(sh-180)//2}")
        tf = tk.Frame(dlg, bg=C["panel"], padx=20, pady=20); tf.pack(fill="both", expand=True)
        tk.Label(tf, text=f"Playlist '{pl['name']}' aktualisieren?",
                 bg=C["panel"], fg=C["text"], font=(F,11,"bold")).pack(anchor="w")
        src_s = ("…"+pl['src'][-60:]) if len(pl.get('src',''))>62 else pl.get('src','')
        tk.Label(tf, text=src_s, bg=C["panel"], fg=C["dim"], font=("Consolas",8)).pack(anchor="w",pady=4)
        bf = tk.Frame(tf, bg=C["panel"]); bf.pack(anchor="w", pady=8)
        def _do():
            dlg.destroy()
            ImportDlg(self, slot, self._on_import_done)
        tk.Button(bf, text="⟳  Aktualisieren", command=_do,
                  bg=C["red"], fg="white", font=(F,10,"bold"),
                  relief="flat", cursor="hand2", padx=14, pady=7).pack(side="left", padx=(0,8))
        tk.Button(bf, text="Abbrechen", command=dlg.destroy,
                  bg=C["card2"], fg=C["dim"], font=(F,10),
                  relief="flat", cursor="hand2", padx=14, pady=7).pack(side="left")

    def _delete(self, slot):
        pl = pl_get(slot)
        name = pl["name"] if pl else f"Slot {slot}"
        if not messagebox.askyesno("Anbieter löschen",
                                   f"'{name}' wirklich löschen?\n\nAlle Kanäle dieses Anbieters werden entfernt.",
                                   parent=self):
            return
        pl_del(slot)
        cfg_set(f"pl_err_{slot}", "")
        if self.app.slot == slot:
            self.app.slot = None
            pls = pl_all()
            if pls:
                self.app.slot = pls[0]["slot"]
                cfg_set("slot", self.app.slot)
        self.refresh()
        self.app.reload()

    def refresh(self):
        self._build_list()


# ═══════════════════════════════════════════════════════════
# HAUPT-APP
# ═══════════════════════════════════════════════════════════
TABS=[
    ("live",     "📺  Live TV",          C["red"]),
    ("video",    "🎬  Filme",            C["purple"]),
    ("series",   "🎭  Serien",           C["teal"]),
    ("continue", "▶  Continue",          C["orange"]),
    ("search",   "🔍  Suche",            C["cyan"]),
    ("provider", "📋  Anbieter",         C["red2"]),
    ("settings", "⚙  Einstellungen",    C["dim"]),
]

class App:
    def __init__(self,root):
        self.root=root; self.player=make_player()
        self.slot=cfg_get("slot",None)
        if not self.slot:
            pls=pl_all()
            if pls: self.slot=pls[0]["slot"]
        self._pages={}; self._lists={}; self._tab="live"
        self._logo_img=None; self._npp=None
        self._build()
        root.after(300,self.reload)
        # mpv automatisch installieren wenn nicht gefunden
        if not self.player.ok:
            root.after(800,self._auto_mpv)

    def _auto_mpv(self):
        """mpv-Installation anbieten falls nicht gefunden."""
        self.player.refresh()
        if self.player.ok: return
        ans = messagebox.askyesno(
            "Kein Video-Player gefunden",
            "Weder VLC noch mpv ist installiert.\n\n"
            "Option 1 (empfohlen): VLC installieren\n"
            "  https://videolan.org/vlc\n\n"
            "Option 2: mpv via winget installieren\n"
            "  (funktioniert ohne Internet-Download)\n\n"
            "Soll mpv jetzt via winget installiert werden?",
            parent=self.root)
        if ans:
            def _done(exe):
                self.player.refresh()
                if exe:
                    messagebox.showinfo("Fertig", f"✅ mpv installiert!\nKanäle können jetzt abgespielt werden.", parent=self.root)
                    self.reload()
            MpvInstallerDlg(self.root, _done)

    def _build(self):
        hf=tk.Frame(self.root,bg=C["hdr"],height=56); hf.pack(fill="x"); hf.pack_propagate(False)
        lf=tk.Frame(hf,bg=C["hdr"]); lf.pack(side="left",padx=10,fill="y")
        loaded=False
        for fn in ("assets/icon_hdr.png","assets/icon_256.png","assets/logo_nobg.png"):
            p=res(fn)
            if PIL_OK and os.path.exists(p):
                try:
                    raw=Image.open(p).convert("RGBA"); raw=raw.resize((48,48),Image.LANCZOS)
                    bg=Image.new("RGBA",(48,48),(10,10,30,255)); bg.paste(raw,(0,0),raw)
                    self._logo_img=ImageTk.PhotoImage(bg.convert("RGB"))
                    tk.Label(lf,image=self._logo_img,bg=C["hdr"],borderwidth=0).pack(side="left",pady=4)
                    loaded=True; break
                except: pass
        if not loaded: tk.Label(lf,text="EX IPTV",bg=C["hdr"],fg=C["red"],font=(F,16,"bold")).pack(side="left",pady=14)
        tk.Frame(hf,bg=C["red"],width=2).pack(side="left",fill="y",padx=8,pady=8)
        inf=tk.Frame(hf,bg=C["hdr"]); inf.pack(side="left",fill="y",pady=8)
        self.pl_lbl =tk.Label(inf,text="",bg=C["hdr"],fg=C["text"],font=(F,10,"bold")); self.pl_lbl.pack(anchor="w")
        self.exp_lbl=tk.Label(inf,text="",bg=C["hdr"],fg=C["yellow"],font=(F,8));       self.exp_lbl.pack(anchor="w")
        cf=tk.Frame(hf,bg=C["hdr"]); cf.pack(side="right",padx=12,fill="y")
        self.player.refresh()
        mpv_c=C["green"] if self.player.ok else C["red2"]
        mpv_t=self.player.backend if self.player.ok else "kein Player"
        self.mpv_lbl=tk.Label(cf,text=mpv_t,bg=C["hdr"],fg=mpv_c,font=(F,8,"bold"),cursor="hand2")
        self.mpv_lbl.pack(anchor="e",pady=(4,0))
        self.mpv_lbl.bind("<Button-1>",lambda e:self._sw("settings"))
        self.tl=tk.Label(cf,text="",bg=C["hdr"],fg=C["text"],font=(F,13,"bold")); self.tl.pack(anchor="e")
        self.dl=tk.Label(cf,text="",bg=C["hdr"],fg=C["dim"],font=(F,8));          self.dl.pack(anchor="e")
        tb=tk.Frame(self.root,bg=C["panel"],height=44); tb.pack(fill="x"); tb.pack_propagate(False)
        tk.Frame(tb,bg=C["red3"],height=2).pack(side="bottom",fill="x")
        tbf=tk.Frame(tb,bg=C["panel"]); tbf.pack(side="left",fill="y")
        self._tbns={}
        for k,l,col in TABS:
            b=tk.Button(tbf,text=l,font=(F,9,"bold"),bg=C["panel"],fg=C["dim"],
                        relief="flat",cursor="hand2",padx=12,pady=10,
                        activebackground=C["card"],command=lambda x=k:self._sw(x))
            b.pack(side="left"); self._tbns[k]=(b,col)
        # Layout: Links=Liste, Rechts=NowPlaying
        self.cont=tk.Frame(self.root,bg=C["bg"]); self.cont.pack(fill="both",expand=True)
        pw=tk.PanedWindow(self.cont,orient="horizontal",bg=C["bg"],sashwidth=5,sashrelief="flat")
        pw.pack(fill="both",expand=True)
        self._left=tk.Frame(pw,bg=C["bg"]); pw.add(self._left,minsize=280,width=400)
        self._npp=NowPlayingPanel(pw,self.player,self); pw.add(self._npp,minsize=380)
        # Tab-Pages
        self._pages["live"]     =ChanList(self._left,"live",    self._play)
        self._pages["video"]    =ChanList(self._left,"video",   self._play)
        self._pages["series"]   =SeriesList(self._left,          self._play)
        self._pages["continue"] =ContinueWatchingPage(self._left,self._play_cw)
        self._pages["search"]   =SearchPage(self._left,          self._play)
        self._pages["provider"] =ProviderPage(self._left,        self)
        self._pages["settings"] =SettingsPage(self._left,        self)
        self._lists["live"]     =self._pages["live"]
        self._lists["video"]    =self._pages["video"]
        self._lists["series"]   =self._pages["series"]
        self._sw("live"); self._tick()

    def _sw(self,k):
        for p in self._pages.values(): p.pack_forget()
        self._pages[k].pack(in_=self._left,fill="both",expand=True)
        for x,(b,col) in self._tbns.items():
            b.config(bg=C["card"] if x==k else C["panel"],fg=col if x==k else C["dim"])
        self._tab=k
        if k=="continue": self._pages["continue"].refresh()
        if k=="search" and self.slot:
            pl=pl_get(self.slot)
            if pl: self._pages["search"].set_pid(pl["pid"])

    def _play(self,ch,start_ms=0):
        # mpv-Status aktualisieren
        self.player.refresh()
        if not self.player.ok:
            self._auto_mpv(); return
        if self._npp: self._npp.play(ch,start_ms=start_ms)

    def _play_cw(self,item,pos_ms):
        self.player.refresh()
        if not self.player.ok: self._auto_mpv(); return
        if self._npp: self._npp.play(item,start_ms=pos_ms)

    def reload(self):
        pl=pl_get(self.slot) if self.slot else None
        if pl:
            self.pl_lbl.config(text=f"  📋  {pl['name']}")
            self.exp_lbl.config(text=f"  📅  Gültig bis {pl['exp']}" if pl.get("exp") else "")
            cfg_set("slot",self.slot); pid=pl["pid"]
            for lst in self._lists.values(): lst.load(pid)
            self._pages["search"].set_pid(pid)
        else:
            self.pl_lbl.config(text="  ⚙  Einstellungen → Playlist laden")
            self.exp_lbl.config(text="")
        # ProviderPage refresh
        if "provider" in self._pages:
            self._pages["provider"].refresh()
        # mpv-Status im Header aktualisieren
        self.player.refresh()
        mpv_c=C["green"] if self.player.ok else C["red2"]
        mpv_t=self.player.backend if self.player.ok else "kein Player"
        self.mpv_lbl.config(text=mpv_t,fg=mpv_c)

    def _tick(self):
        n=datetime.now(); self.tl.config(text=n.strftime("%H:%M:%S")); self.dl.config(text=n.strftime("%a, %d. %b %Y"))
        self.root.after(1000,self._tick)

# ═══════════════════════════════════════════════════════════
# START
# ═══════════════════════════════════════════════════════════
def main():
    db_init()
    root=tk.Tk(); root.title("EX IPTV Player v9.0"); root.configure(bg=C["bg"])
    icon=res("assets/icon.ico")
    if os.path.exists(icon):
        try: root.iconbitmap(icon)
        except: pass
    root.update_idletasks()
    sw,sh=root.winfo_screenwidth(),root.winfo_screenheight()
    root.geometry(f"1380x800+{(sw-1380)//2}+{(sh-800)//2}")
    root.minsize(880,580)
    App(root)
    root.mainloop()

if __name__=="__main__": main()
