"""
EX IPTV — Icon Generator
Erstellt Icons aus logo_original.png.
Falls logo_original.png fehlt → automatisch Fallback-Icon generieren.
"""
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance
from collections import deque
import os, sys


def make_fallback_icon(size):
    """Professionelles Fallback-Icon (rotes TV-Logo mit Play-Symbol)."""
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    m = size // 10
    # Roter Hintergrund-Kreis
    d.ellipse([m, m, size-m, size-m], fill=(200, 20, 20, 255))
    # Weißer Bildschirm
    bx1, by1 = size//5, size//4
    bx2, by2 = size*4//5, size*3//4
    r = size // 16
    d.rounded_rectangle([bx1, by1, bx2, by2], radius=r, fill=(255, 255, 255, 240))
    # Rotes Play-Dreieck
    cx = (bx1+bx2)//2; cy = (by1+by2)//2; tr = (by2-by1)//3
    d.polygon([(cx-tr, cy-tr), (cx-tr, cy+tr), (cx+tr, cy)], fill=(200, 20, 20, 255))
    # Sockel
    sx1, sx2 = size*3//8, size*5//8
    sy1, sy2 = by2, by2 + size//12
    d.rectangle([sx1, sy1, sx2, sy2], fill=(255, 255, 255, 200))
    d.rectangle([sx1 - size//10, sy2, sx2 + size//10, sy2 + size//20], fill=(255, 255, 255, 200))
    return img


def remove_white_bg(img):
    """Entfernt weißen Hintergrund per BFS-Flood-Fill vom Rand."""
    img = img.convert("RGBA")
    w, h = img.size; px = img.load()

    def is_bg(p): r,g,b,a = p; return r > 222 and g > 222 and b > 222

    visited  = [[False]*h for _ in range(w)]
    is_bg_m  = [[False]*h for _ in range(w)]
    q = deque()

    for x in range(w):
        for y in (0, h-1):
            if not visited[x][y] and is_bg(px[x,y]):
                visited[x][y] = True; is_bg_m[x][y] = True; q.append((x,y))
    for y in range(h):
        for x in (0, w-1):
            if not visited[x][y] and is_bg(px[x,y]):
                visited[x][y] = True; is_bg_m[x][y] = True; q.append((x,y))

    while q:
        x, y = q.popleft()
        for dx, dy in ((1,0),(-1,0),(0,1),(0,-1)):
            nx, ny = x+dx, y+dy
            if 0 <= nx < w and 0 <= ny < h and not visited[nx][ny] and is_bg(px[nx,ny]):
                visited[nx][ny] = True; is_bg_m[nx][ny] = True; q.append((nx,ny))

    out = img.copy(); op = out.load()
    for x in range(w):
        for y in range(h):
            r, g, b, a = px[x,y]
            if is_bg_m[x][y]:
                op[x,y] = (r, g, b, 0)
            elif is_bg(px[x,y]):
                nbg = sum(1 for dx,dy in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1))
                          if 0<=x+dx<w and 0<=y+dy<h and is_bg_m[x+dx][y+dy])
                if nbg > 0: op[x,y] = (r, g, b, max(0, 255 - nbg*45))
    return out


def sharpen(img, size, extra=False):
    r = img.resize((size, size), Image.LANCZOS)
    if extra or size <= 64:
        r = r.filter(ImageFilter.UnsharpMask(radius=1.0, percent=220, threshold=2))
    return ImageEnhance.Sharpness(r).enhance(1.6)


def main():
    os.makedirs("assets", exist_ok=True)
    src = "assets/logo_original.png"

    logo = None
    if os.path.exists(src):
        print("  Logo gefunden — entferne Hintergrund...")
        try:
            logo = remove_white_bg(Image.open(src))
            logo.save("assets/logo_nobg.png")
            print("  ✅ logo_nobg.png (aus Logo)")
        except Exception as e:
            print(f"  ⚠  Logo-Fehler ({e}) — verwende Fallback")
            logo = None

    if logo is None:
        print("  ℹ  Kein Logo — erstelle Standard-Icon...")
        logo = make_fallback_icon(512)
        logo.save("assets/logo_nobg.png")
        print("  ✅ logo_nobg.png (Fallback)")

    # ICO (16 bis 256px)
    sizes = [16, 24, 32, 48, 64, 128, 256]
    imgs  = [sharpen(logo, s) for s in sizes]
    imgs[0].save("assets/icon.ico", format="ICO",
                 sizes=[(s,s) for s in sizes],
                 append_images=imgs[1:])
    print("  ✅ icon.ico")

    # Header-Icon (52px auf dunklem Hintergrund)
    i52  = sharpen(logo, 52, extra=True)
    bg52 = Image.new("RGBA", (52,52), (10,10,30,255))
    bg52.paste(i52, (0,0), i52)
    bg52.save("assets/icon_hdr.png")
    print("  ✅ icon_hdr.png")

    sharpen(logo, 256).save("assets/icon_256.png")
    print("  ✅ icon_256.png")


if __name__ == "__main__":
    main()
