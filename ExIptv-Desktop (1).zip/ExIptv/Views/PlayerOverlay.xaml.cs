using System.Windows;
using System.Windows.Controls;
using ExIptv.ViewModels;

namespace ExIptv.Views;

public partial class PlayerOverlay : Window
{
    public PlayerOverlay(MainViewModel viewModel)
    {
        InitializeComponent();
        DataContext = viewModel;
    }

    // Klick in der Overlay-Senderliste schaltet sofort um (wie die Hauptliste bei Live).
    private void OnChannelSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (DataContext is MainViewModel vm
            && sender is ListBox { SelectedItem: PlayableItem item }
            && !ReferenceEquals(item, vm.SelectedItem))
        {
            vm.SelectedItem = item;
            vm.ActivateItemCommand.Execute(item);
        }
    }
}
