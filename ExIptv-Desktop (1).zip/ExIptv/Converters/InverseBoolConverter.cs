using System.Globalization;
using System.Windows.Data;

namespace ExIptv.Converters;

/// <summary>Negiert einen Bool (z. B. IsBusy -> IsEnabled).</summary>
public sealed class InverseBoolConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) => value is not true;
    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) => value is not true;
}
